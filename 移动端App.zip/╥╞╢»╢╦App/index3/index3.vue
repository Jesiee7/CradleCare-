<template>
  <div class="gray-bg">
    <div class="online">
      <span class="online">测试在线人数：<span id="online">{{ onlineCount }}</span>&nbsp人</span>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        onlineCount: 0,
        websocket: null
      };
    },
    mounted() {
      this.initializeWebSocket();
    },
    methods: {
      initializeWebSocket() {
        let host = document.location.host;
        if ('WebSocket' in window) {
          this.websocket = new WebSocket("ws://" + host + "/webSocket");
          this.websocket.onopen = this.onWebSocketOpen;
          this.websocket.onmessage = this.onWebSocketMessage;
          this.websocket.onerror = this.onWebSocketError;
          this.websocket.onclose = this.onWebSocketClose;
        } else {
          alert('浏览器不支持webSocket');
        }
      },
      onWebSocketOpen(event) {
        console.log("WebSocket连接已建立");
      },
      onWebSocketMessage(event) {
        let data = event.data;
        console.log("后端传递的数据:" + data);
        this.onlineCount = data; // 更新在线人数
      },
      onWebSocketError() {
        console.error("WebSocket连接发生错误");
      },
      onWebSocketClose() {
        console.log("WebSocket连接已关闭");
      },
      send() {
        let message = document.getElementById('text').value;
        this.websocket.send(message);
      },
      closeWebSocket() {
        this.websocket.close();
      }
    }
  };
</script>