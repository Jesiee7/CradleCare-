<template>
  <view class="pages_height">


    <view class="online">
      <span class="online">测试在线人数：<span id="online"></span>&nbsp人</span>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        webSocketObject: null,

      }
    },
    mounted() {
      //初始化WebSocket
      this.webSocketInit()
    },
    beforeDestroy() {
      this.webSocketObject.close(); //在该组件销毁时关闭该连接以节约资源
    },
    methods: {
      webSocketInit() {
        if ('WebSocket' in window) {
          this.webSocketObject = new WebSocket('ws://127.0.0.1:9096/webSocket');
          this.webSocketObject.onOpen = this.webSocketOnOpen
          this.webSocketObject.onMessage = this.webSocketOnMessage
          this.webSocketObject.onError = this.webSocketOnError
          this.webSocketObject.onClose = this.webSocketOnClose
        } else {
          alert('浏览器不支持webSocket');
        }
      },
      webSocketOnOpen(e) {
        console.log('与服务端连接打开->', e)
      },
      webSocketOnMessage(e) {
        console.log('来自服务端的消息->', e)
        const receiveMessage = JSON.parse(e.data);
        this.messageList.push(receiveMessage)
      },
      webSocketOnError(e) {
        console.log('与服务端连接异常->', e)
      },
      webSocketOnClose(e) {
        console.log('与服务端连接关闭->', e)
      },
      handleSendButton() {
        const username = this.username
        const message = this.sendMessage
        this.webSocketObject.send(JSON.stringify({
          id: 1,
          message,
          username,
          time: new Date().getTime()
        }))
        this.sendMessage = ''
      },
      handleLogoutButton() {
        removeUsername() //清除username然后断开连接
        this.webSocketObject.close();
        this.$router.push({
          name: 'Login'
        })
      }
    },

  }
</script>

<style scoped>

</style>