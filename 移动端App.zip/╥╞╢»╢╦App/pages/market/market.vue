<template>
  <view>
    <u-navbar back-text="商城" :background="background" :custom-back="back">
      <view class="slot-wrap">
        <u-search placeholder="日照香炉生紫烟" v-model="keyword"></u-search>
        <image src="../../static/cart.png" class="image1" @click="cartClick"></image>
      </view>
    </u-navbar>
    <view class="wrap">
      <u-swiper :list="list" height="378"></u-swiper>
    </view>

    <!---->
    <u-tabs :list="tabs_list" :is-scroll="false" :current="current" @change="change" active-color="#ff0b89" class="tabs"
      bg-color="#f8f8f8"></u-tabs>

    <!---->
    <view v-if="current == 0" class="sp">

      <view class="shangpin" v-for="(item, index) in goods" :key="index">
        <u-link :href="item.url" text="打开uView UI文档" color="#19be6b" class="shangpin-item3">
          <image :src="item.image" class="shangpin-img"></image>
          <view class="shangpin-item1">{{item.name}}</view>
          <view class="shangpin-item2">到手￥{{item.price}}</view>
        </u-link>

      </view>
    </view>

    <!---->
    <view v-if="current == 1" class="sp">

      <view class="shangpin" v-for="(item, index) in goods1" :key="index">
        <u-link :href="item.url" text="打开uView UI文档" color="#19be6b" class="shangpin-item3">
          <image :src="item.image" class="shangpin-img"></image>
          <view class="shangpin-item1">{{item.name}}</view>
          <view class="shangpin-item2">到手￥{{item.price}}</view>
        </u-link>

      </view>
    </view>

    <!---->
    <view v-if="current == 2" class="sp">

      <view class="shangpin" v-for="(item, index) in goods2" :key="index">
        <u-link :href="item.url" text="打开uView UI文档" color="#19be6b" class="shangpin-item3">
          <image :src="item.image" class="shangpin-img"></image>
          <view class="shangpin-item1">{{item.name}}</view>
          <view class="shangpin-item2">到手￥{{item.price}}</view>
        </u-link>

      </view>
    </view>

    <!---->
    <view v-if="current == 3" class="sp">

      <view class="shangpin" v-for="(item, index) in goods3" :key="index">
        <u-link :href="item.url" text="打开uView UI文档" color="#19be6b" class="shangpin-item3">
          <image :src="item.image" class="shangpin-img"></image>
          <view class="shangpin-item1">{{item.name}}</view>
          <view class="shangpin-item2">到手￥{{item.price}}</view>
        </u-link>

      </view>
    </view>

    <!---->
    <view v-if="current == 4" class="sp">

      <view class="shangpin" v-for="(item, index) in goods4" :key="index">
        <u-link :href="item.url" text="打开uView UI文档" color="#19be6b" class="shangpin-item3">
          <image :src="item.image" class="shangpin-img"></image>
          <view class="shangpin-item1">{{item.name}}</view>
          <view class="shangpin-item2">到手￥{{item.price}}</view>
        </u-link>

      </view>
    </view>

  </view>
</template>

<script>
  export default {
    data() {
      return {
        list: [{
            image: '/static/微信图片_20240416155236.png',
            title: '2'
          },
          {
            image: '/static/微信图片_20240416155224.png',
            title: '3'
          },
          {
            image: '/static/微信图片_20240416155235.png',
            title: '4'
          }
        ],

        background: {
          backgroundImage: 'linear-gradient(45deg, #98fdfe, #eeffff)'
        },
        tabs_list: [{
          name: '推荐'
        }, {
          name: '母婴'
        }, {
          name: '美食'
        }, {
          name: '美妆'
        }, {
          name: '居家'
        }],
        current: 0,

        //
        token: '',

        //
        goods: {},
        goods1: {},
        goods2: {},
        goods3: {},
        goods4: {},
      }
    },
    onLoad() {
      const val = uni.getStorageSync('jwtToken')
      this.token = val
    },
    onShow() {
      uni.request({
        url: 'http://localhost:9096/selectallgoods',
        data: {
          typename: 'goods'
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          this.goods = res.data
        }
      });

      uni.request({
        url: 'http://localhost:9096/selectallgoods',
        data: {
          typename: 'goods1'
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          this.goods1 = res.data
        }
      });

      uni.request({
        url: 'http://localhost:9096/selectallgoods',
        data: {
          typename: 'goods2'
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          this.goods2 = res.data
        }
      });

      uni.request({
        url: 'http://localhost:9096/selectallgoods',
        data: {
          typename: 'goods3'
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          this.goods3 = res.data
        }
      });

      uni.request({
        url: 'http://localhost:9096/selectallgoods',
        data: {
          typename: 'goods4'
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          this.goods4 = res.data
        }
      });
    },

    methods: {
      cartClick() {
        uni.navigateTo({
          url: '/pages/cart/cart'
        })
      },
      change(e) {
        this.current = e
      },
      back() {
        uni.switchTab({
          url: '/pages/my/my'
        })
      }
    }
  }
</script>

<style>
  .slot-wrap {
    display: flex;
    flex-direction: row;
  }

  .image1 {
    padding-left: 10rpx;
    width: 50rpx;
    height: 50rpx;
  }



  .grid-box {
    margin: 10rpx 0;
  }

  .box1 {
    background-color: #fff;
    margin-top: 40rpx;
    margin-left: 40rpx;
    padding: 20rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 670rpx;
    height: 350rpx;
  }

  .text1 {
    font-size: big;
    font-weight: 800;
  }

  .wrap {
    margin: 30rpx 40rpx;
    width: 672rpx;
    height: 400rpx;
  }

  .sp {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    align-items: center;
  }

  .shangpin {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 10rpx;
    padding: 5rpx 5rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 48%;
    height: 600rpx;
  }

  .shangpin-img {
    width: 340rpx;
    height: 460rpx;
  }

  .shangpin-item1 {
    font-size: 35rpx;
    color: #38506D;
    font-weight: bold;
  }

  .shangpin-item2 {
    font-size: 35rpx;
    color: #ff0b89;
    font-weight: bold;
  }
</style>