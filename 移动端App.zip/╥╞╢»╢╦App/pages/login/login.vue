<template>
  <view class="wrap">
    <u-form :model="user" ref="uForm">
      <u-form-item left-icon="account" label-width="120" label="账号" prop="id">
        <u-input placeholder="请输入账号" v-model="user.id" type="text"></u-input>
      </u-form-item>
      <u-form-item left-icon="lock" label-width="120" label="密码" prop="password">
        <u-input :password-icon="true" type="password" v-model="user.password" placeholder="请输密码"></u-input>
      </u-form-item>
      <!-- 此处switch的slot为right，如果不填写slot名，也即<u-switch vmodel="model.remember"></u-switch>，将会左对⻬ -->

    </u-form>
    <u-button @click="submit">提交</u-button>
    <u-button @click="go">注册</u-button>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        user: {
          id: '',
          password: ''
        },
        token: '',
        fontSize: 28,
      }
    },
    onShow() {
      const value = uni.getStorageSync('jwtToken')
      this.token = value
    },
    methods: {
      submit() {
        //获取token
        uni.request({
          url: 'http://localhost:9096/login',
          data: this.user,
          method: "POST",
          success: (res) => {
            this.token = res.data.token
            uni.setStorageSync('jwtToken', res.data.token)
            uni.request({
              url: 'http://localhost:9096/select',
              data: this.user,
              method: "POST",
              header: {
                'token': this.token
              },
              success: (res) => {
                if (res.data.code * 1 == 1) { //成功登录
                  try {
                    uni.setStorageSync('user', res.data); //将⽤户对象本地存储 以
                    uni.switchTab({
                      url: '/pages/my/my'
                    }) //登录成功返回 我的个⼈信息⻚⾯
                  } catch (e) {
                    this.$u.toast('身份信息格式异常')
                  }
                } else {
                  this.$u.toast('登录失败，用户名密码错误') //提示框
                }
              }
            });
          }
        })

      },
      go() {
        uni.navigateTo({
          url: "/pages/register/register"
        })
      }
    }

  }
</script>

<style>

</style>