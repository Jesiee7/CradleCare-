<template>
  <view class="top-box">
    <u-navbar title="添加记录" background="#91919114">
      <u-button class="top-add" @click="baocun()">保存</u-button>
    </u-navbar>
    <view class="jilu-list">
      <u-form :model="baby" ref="uForm">
        <u-form-item label-width="120" label="身高" prop="height">
          <u-input input-align="right" placeholder="请输入身高" v-model="baby.height" type="text"></u-input>
          <text class="jilu-list-text1">cm</text>
        </u-form-item>

        <u-form-item label-width="120" label="体重" prop="weight">
          <u-input input-align="right" placeholder="请输入体重" v-model="baby.weight" type="text"></u-input>
          <text class="jilu-list-text1">kg</text>
        </u-form-item>

        <u-form-item label-width="120" label="头围" prop="head">
          <u-input input-align="right" placeholder="请输入头围" v-model="baby.head" type="text"></u-input>
          <text class="jilu-list-text1">cm</text>
        </u-form-item>

        <u-form-item label-width="140" label="测量日期" prop="time" :border-bottom="false">
          <u-calendar v-model="show" :mode="mode" @change="dateChange"></u-calendar>
          <u-cell-item title="" :arrow="true" arrow-direction="right" :border-bottom="false" @click="show = true">
            <text class="jilu-list-text1">{{baby.time}}</text>
          </u-cell-item>

        </u-form-item>



      </u-form>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        baby: {
          height: '',
          weight: '',
          head: '',
          time: '',
        },
        show: false,
        mode: 'date',

      }
    },
    methods: {
      dateChange(e) {
        this.baby.time = e.result
      },
      baocun() {
        uni.request({
          url: 'http://192.168.236.203:9000/newAllH',
          data: {
            height: this.baby.height,
            weight: this.baby.weight,
            head: this.baby.head,
          },
          method: "POST",
          success: (res) => {
            console.log("111")
            uni.navigateBack()
          }
        });
      }
    }
  }
</script>

<style>
  .top-box {
    display: flex;
    flex-direction: column;
    background-color: #d9d9d914;
    height: 1750rpx;
    width: 100%;
  }

  .top-add {
    margin-left: 500rpx;
    background-color: #ff0b89;
    color: #fff;
    border-radius: 20px;
  }

  .jilu-list {
    background-color: #fff;
    margin-top: 40rpx;
    margin-left: 40rpx;
    padding: 10rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 670rpx;
    height: 500rpx;
  }

  .jilu-list-text1 {
    padding-left: 10rpx;
    color: #000000;
  }
</style>