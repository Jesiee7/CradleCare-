<template>
  <view class="page">

    <!-- 名字展示 -->
    <view class="huanying-box">
      <view class="huanying">
        <text class="text1">{{yonghu.name}}</text>
        <view class="box2" v-if="house.room_state==1">
          <image class="image2" src="/static/green-cir.png" />
          <text class="grid2">有人</text>
        </view>
        <!--   -->
        <view v-else-if="house.room_state==0" class="box2">
          <image class="image2" src="/static/red-cir.png" />
          <text class="grid-text1">{{room[1]}}</text>
        </view>
      </view>

      <image src="/static/add.png" class="huanying_image" @click="pop_show = true"></image>

      <!--增加宝贝弹出层-->
      <u-popup v-model="pop_show" mode="center" width="600rpx" height="240px" closeable="true">
        <u-form :model="baby" ref="uForm" class="pop-item">
          <u-form-item left-icon="account" label-width="140" label="用户名" prop="baby_name">
            <u-input placeholder="请输入宝贝名字" v-model="baby.baby_name" type="text"></u-input>
          </u-form-item>
          <u-button @click="addClick" class="button1">提交</u-button>
        </u-form>
      </u-popup>

    </view>


    <!---->
    <view>
      <text class="text3">宝贝的床铺</text>
      <view class="grid-box">
        <view class="grid-first" @click="temp">
          <u-circle-progress active-color="#14D2B8" :percent="house.temp" :width="270">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-info'>{{house.temp}}</view>
              <view class="u-progress-info1" v-if="house.temp != ''">正常</view>
            </view>
          </u-circle-progress>
          <view class="grid-text">
            <image src="../../static/temp.png" class="image4"></image>温度检测
          </view>
        </view>

        <view class="grid-first" @click="humi">
          <u-circle-progress active-color="#6E5EFF" :percent="house.hum" :width="270">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-info'>{{house.hum}}</view>
              <view class="u-progress-info2" v-if="house.hum != ''">正常</view>
            </view>
          </u-circle-progress>
          <view class="grid-text">
            <image src="/static/humi.png" class="image3"></image>湿度检测
          </view>
        </view>
      </view>

      <!---->
      <text class="text3">宝贝的手环</text>
      <view class="grid-box1">
        <view class="grid-shouhuan" v-if="hand.s_temp < 37">
          <u-circle-progress active-color="#FF7071" :percent="hand.s_temp / 37 * 100">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.s_temp}}</view>
              <view class="u-progress-inf1" v-if="house.s_temp != ''">正常</view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝温度</view>
        </view>
        <view class="grid-shouhuan" v-else>
          <u-circle-progress active-color="#FF7071" :percent="hand.s_temp / 37 * 100">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.s_temp}}</view>
              <view class="u-progress-inf1"></view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝可能发烧了</view>
        </view>

        <view class="grid-shouhuan" v-if="hand.spO2 < 100">
          <u-circle-progress active-color="#5AFFE3" :percent="hand.spO2">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.spO2}}</view>
              <view class="u-progress-inf2" v-if="house.spO2 != ''">正常</view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝血氧</view>
        </view>

        <view class="grid-shouhuan" v-else>
          <u-circle-progress active-color="#5AFFE3" :percent="hand.spO2">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.spO2}}</view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝血氧异常</view>
        </view>

        <view class="grid-shouhuan" v-if="hand.heart < 120">
          <u-circle-progress active-color="#FF912A" :percent="hand.heart">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.heart}}</view>
              <view class="u-progress-inf3" v-if="house.heart != ''">正常</view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝心率</view>
        </view>

        <view class="grid-shouhuan" v-else>
          <u-circle-progress active-color="#FF912A" :percent="hand.heart">
            <view class="u-progress-content">
              <view class="u-progress-dot"></view>
              <view class='u-progress-inf'>{{hand.heart}}</view>
            </view>
          </u-circle-progress>
          <view class="grid-text2">宝贝心率异常</view>
        </view>
      </view>

      <text class="text3">智能调节</text>
      <view class="grid-box">
        <view class="grid-left">
          <u-select v-model="show" :list="list" @confirm="lightConfirm"></u-select>
          <view class="text6">灯光{{dangwei}}</view>
          <image class="image5" src="../../static/light.png" @click="show = true"></image>
          <u-line-progress :striped="true" active-color="#FF8189" :percent="70" :show-percent="false" :height="10"
            class="line"></u-line-progress>
        </view>
        <view class="grid-mid">
          <u-select v-model="check" :list="wind_list" @confirm="windConfirm"></u-select>
          <view class="text6">风扇{{wind}}</view>
          <image class="image6" src="/static/wind.png" @click="check = true"></image>
        </view>

        <view class="grid-right">
          <u-select v-model="music_show" :list="music_list" @confirm="musicConfirm"></u-select>
          <view class="text6" v-if="music == '' || music == '关'">音乐</view>
          <view class="text6" v-else>{{music}}</view>
          <image class="image7" src="/static/music.png" @click="music_show = true"></image>
        </view>
      </view>


    </view>
  </view>
  </view>
</template>

<script>
  export default {
    components: {},
    props: {},
    data() {
      return {
        //背景
        background: {
          backgroundImage: 'linear-gradient(45deg, rgb(28, 187, 180), rgb(141, 198, 63))'
        },

        //添加弹出层
        pop_show: false,
        baby: {
          baby_name: '',
        },
        baby_name: '',

        //房间选择弹出层
        fangjian: false,
        room_list: [{
            value: '1',
            label: '主卧室'
          },
          {
            value: '2',
            label: '客卧室'
          },
          {
            value: '3',
            label: '客厅'
          },
        ],

        //房间选择
        room_check: '房间选择',

        //婴儿床选择
        baby_list: [],
        current: 0, // tabs组件的current值，表示当前活动的tab选项
        swiperCurrent: 0,
        dx: 0, //偏移量

        //温度，湿度
        s_temperature: '',
        temperature: '40',
        humidity: '50',

        //调节档位
        show: false,
        check: false,
        dangwei: '',
        wind: '',
        list: [{
            value: '5',
            label: '开'
          },
          {
            value: '6',
            label: '关'
          },
          {
            value: '7',
            label: '闪烁'
          }
        ],
        wind_list: [{
            value: '0',
            label: '关'
          },
          {
            value: '1',
            label: '1档'
          },
          {
            value: '2',
            label: '2档'
          },
          {
            value: '3',
            label: '3档'
          }
        ],

        //房间状态
        room_show: false,
        room: ['有人', '没人'],

        //温湿度检测
        tem_show: true,
        humi_show: false,

        //
        logined: false,
        yonghu: {
          xingming: '游客'
        },

        //
        house: {
          hum: '',
          msg: '',
          room_state: '',
          temp: '',
        },
        hand: {
          heart: '',
          s_temp: '',
          spO2: '',
          msg: '',
        },
        token: '',

        //
        by: {
          id: '',
          babyname: '',
          location: '',
        },

        //存取baby_list最后一个值
        tep: '',

        //
        music_show: false,
        music_list: [{
            value: '0',
            label: '关'
          },
          {
            value: '1',
            label: '俩只老虎'
          },
          {
            value: '2',
            label: '安眠曲'
          },
          {
            value: '3',
            label: 'see you again'
          }
        ],
        music: '',
      };
    },
    mounted() {
      this.fetchState();
      setInterval(() => {
        this.fetchState()();
      }, 5000);
    },
    onLoad() {
      const val = uni.getStorageSync('jwtToken')
      this.token = val
    },
    onShow() {
      try {
        const value = uni.getStorageSync('user')
        if (value) {
          if (!this.logined) { //从未登录变为登录
            this.yonghu = value
          }
          this.logined = true
        } else {
          this.logined = false
        }
      } catch (e) {
        // error
      }
      uni.request({
        url: 'http://localhost:9096/selectbaby',
        data: {
          id: this.yonghu.id
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          if (this.baby_list.length >= res.data.length) {
            return
          } else {
            for (let i = 0; i < res.data.length; i++) {
              this.baby_list.push({
                name: res.data[i].babyname,
              })
            }
            console.log(this.baby_list)
            this.room_check = res.data[0].location
            console.log(this.room_check)
          }
        }
      });


    },
    methods: {
      //qingqiuhanshu
      fetchState() {
        uni.request({
          url: 'http://192.168.236.203:9000/getHouse',
          data: this.house,
          method: "GET",
          success: (res) => {
            this.house = res.data.data
          }
        });
        uni.request({
          url: 'http://192.168.236.203:9000/getHand',
          data: this.hand,
          method: "GET",
          success: (res) => {
            this.hand = res.data.data
          }
        });

        uni.request({
          url: 'http://192.168.236.203:9000/getRoom',
          data: this.yonghu,
          method: "GET",
          success: (res) => {
            console.log(res)
            this.house.room_state = res.data.data.room_state
          }
        });
      },

      addClick() {
        if (this.baby_list == '') {
          this.baby_name = this.baby.baby_name
          this.baby.baby_name = ''
          this.pop_show = false
        } else {
          this.baby_name = this.baby.baby_name
          this.baby.baby_name = ''
          uni.request({
            url: 'http://localhost:9096/addbaby',
            data: {
              id: this.yonghu.id,
              babyname: this.baby_name,
              location: this.room_check,
            },
            header: {
              'token': this.token
            },
            method: "POST",
            success: (res) => {
              console.log(res)
            }
          });
          uni.request({
            url: 'http://localhost:9096/selectbaby',
            data: {
              id: this.yonghu.id
            },
            header: {
              'token': this.token
            },
            method: "POST",
            success: (res) => {
              if (this.baby_list.length >= res.data.length) {
                return
              } else {
                for (const i of res.data) {
                  this.tep = i.babyname
                }
                this.baby_list.push({
                  name: this.tep,
                })
              }
            }
          });
          this.pop_show = false
        }

      },

      roomCheck() {
        if (this.logined == false) {
          this.$u.toast('请先登录')
        } else if (this.baby_name == '') {
          this.$u.toast('请先添加宝贝')
          this.pop_show = true
        } else if (this.baby_name != '' && this.room_check == '房间选择') {
          this.fangjian = true
        } else if (this.room_check != '房间选择') {
          this.$u.toast('已有房间，请直接添加宝贝')
          this.pop_show = true
        }

      },
      temp() {
        uni.navigateTo({
          url: '/pages/temperature/temperature'
        })
      },
      humi() {
        uni.navigateTo({
          url: '/pages/humidity/humidity'
        })
      },
      lightConfirm(e) {
        this.dangwei = e[0].label
        uni.request({
          url: 'http://192.168.236.203:9000/hdbz/fan',
          data: {
            fan: ':' + e[0].value
          },
          method: "POST",
          success: (res) => {
            console.log(res)
          }
        });
      },
      windConfirm(e) {
        this.wind = e[0].label
        uni.request({
          url: 'http://192.168.236.203:9000/hdbz/fan',
          data: {
            fan: ':' + e[0].value
          },
          method: "POST",
          success: (res) => {
            console.log(res)
          }
        });
      },
      roomConfirm(e) {
        this.room_check = e[0].label
        uni.request({
          url: 'http://localhost:9096/addbaby',
          data: {
            id: this.yonghu.id,
            babyname: this.baby_name,
            location: this.room_check,
          },
          header: {
            'token': this.token
          },
          method: "POST",
          success: (res) => {
            console.log(res)
          }
        });
        uni.request({
          url: 'http://localhost:9096/selectbaby',
          data: {
            id: this.yonghu.id
          },
          header: {
            'token': this.token
          },
          method: "POST",
          success: (res) => {
            if (this.baby_list.length >= res.data.length) {
              return
            } else {
              for (let i = 0; i < res.data.length; i++) {
                this.baby_list.push({
                  name: res.data[i].babyname,
                })
              }
              this.room_check = res.data[0].location
              console.log(this.room_check)
            }
          }
        });

      },

      // tab栏下标切换
      change(index) {
        this.swiperCurrent = index;
      },
      // tab栏偏移量切换
      transition({
        detail: {
          dx
        }
      }) {
        this.$refs.tabs.setDx(dx);
      },
      // tab栏内容切换
      animationfinish({
        detail: {
          current
        }
      }) {
        this.swiperCurrent = current;
        this.current = current;
      },

      //
      musicConfirm(e) {
        this.music = e[0].label
        uni.request({
          url: 'http://192.168.236.203:9000/hdbz/music',
          data: {
            beeper: ':' + e[0].value
          },
          method: "POST",
          success: (res) => {
            console.log(res)
          }
        });
      }

    },
  };
</script>

<style scoped lang="scss">
  .page {
    padding-top: 50rpx;
    background-color: #fff;
    height: 1750rpx;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    background-image: url('../../static/background.png');
  }

  .tabs {
    width: 720rpx;
    margin: 15rpx;
    border-radius: 15px;
  }

  .image2 {
    margin-left: 50rpx;
    width: 16rpx;
    height: 16rpx;
  }

  .text5 {
    color: #00FF84,
  }

  .box2 {
    margin-top: 10rpx;
  }

  .huanying-box {
    display: flex;
    flex-direction: row;
  }

  .huanying {
    display: flex;
    flex-direction: row;
    padding: 0 40rpx;
    margin-top: 30rpx;
    width: 100%;
  }

  .huanying_image {
    margin-top: 30rpx;
    margin-right: 40rpx;
    width: 50rpx;
    height: 46rpx;
  }

  .text1 {
    padding-left: 200rpx;
    color: #273240;
    font-size: 48rpx;
    font-family: Poppins;
    line-height: 46.46rpx;
  }

  .text2 {
    color: #273240;
    margin-top: 30rpx;
    line-height: 38rpx;
  }

  .group2 {
    margin-top: 60rpx;
  }

  .text3 {
    margin-top: 40rpx;
    margin-left: 30rpx;
    line-height: 38rpx;
    font-size: large;
    padding-left: 15rpx;
    display: flex;
    align-items: center;
    border-left: 4px solid #FF8189;
  }

  .empty {
    padding-top: 150rpx;

  }

  .pop-item {
    margin: 80rpx 0;

  }

  .button1 {
    margin-top: 70rpx;
  }

  /**/
  .swiper_wrap {
    margin-top: 50rpx;
    width: 100%;
    height: calc(100vh - var(--window-top));
    display: flex;
    flex-direction: column;

    .page-box {
      text-align: center;
    }
  }

  .swiper-box {
    flex: 1;
  }

  .swiper-item {
    height: 100%;
  }

  /**/

  .grid-box {
    display: flex;
    flex-direction: row;
  }


  .grid-first {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 30rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 330rpx;
    height: 380rpx;
  }

  .u-progress-dot {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
  }

  .u-progress-info {
    font-size: 60rpx;
    font-weight: bold;
  }

  .u-progress-info1 {
    color: #14D2B8;
    padding-top: 5rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
    font-size: 27rpx;
  }

  .u-progress-info2 {
    display: flex;
    justify-content: space-around;
    align-items: center;
    color: #6E5EFF;
    padding-top: 5rpx;
    font-size: 27rpx;
  }

  .grid-box1 {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 30rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 690rpx;
    height: 330rpx;
  }

  .grid-shouhuan {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
  }

  .u-progress-inf {
    font-size: 40rpx;
    font-weight: bold;
  }

  .u-progress-inf1 {
    color: #FF7071;
    display: flex;
    justify-content: space-around;
    align-items: center;
    font-size: 27rpx;
  }

  .u-progress-inf2 {
    color: #5AFFE3;
    font-size: 27rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .u-progress-inf3 {
    color: #FF912A;
    font-size: 27rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .grid-left {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 30rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 225rpx;
    height: 350rpx;
  }

  .grid-mid {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 225rpx;
    height: 350rpx;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 12rpx;
    padding: 30rpx 0;
  }

  .grid-right {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 30rpx;
    margin-left: 12rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 225rpx;
    height: 350rpx;
  }

  .grid-text1 {
    padding-left: 10rpx;
    font-weight: bold;
    color: #FF4800;
  }

  .grid2 {
    padding-left: 10rpx;
    font-weight: bold;
    color: #06ff2f;
  }

  .grid-text2 {
    padding-top: 20rpx;
  }

  .text4 {
    font-size: 40rpx;
  }

  .text6 {
    font-size: 35rpx;
    color: #38506D;
    font-weight: bold;
  }

  .image1 {
    width: 96rpx;
    height: 96rpx;
  }

  .image3 {
    padding-right: 10rpx;
    width: 28rpx;
    height: 28rpx;
  }

  .image4 {
    padding-right: 10rpx;
    width: 18rpx;
    height: 32rpx;
  }

  .image5 {
    width: 129rpx;
    height: 129rpx;
  }

  .image6 {
    margin-top: 20rpx;
    width: 164rpx;
    height: 178rpx;
  }

  .image7 {
    width: 96rpx;
    height: 164rpx;
  }

  .line {
    width: 180rpx;
  }
</style>