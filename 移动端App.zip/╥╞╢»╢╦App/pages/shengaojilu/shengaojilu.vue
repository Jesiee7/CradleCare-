<template>
  <view class="top-box">
    <u-navbar title="身高体重记录" background="#91919114" :custom-back="back">
      <u-button class="top-add" @click="addRecoder">添加</u-button>
    </u-navbar>

    <u-tabs :list="list" :is-scroll="false" :current="current" @change="change" active-color="#ff0b89" class="tabs"
      bg-color="#d9d9d914"></u-tabs>

    <!--记录列表-->
    <view v-if="current == 0">
      <view class="jilu-list" v-for="(item, index) in baby.data" :key="index">
        <view>{{item.time}}</view>
        <view class="jilu-list-item1">
          <view class="jilu-list-text1">宝宝体重增长偏快、身高增长偏慢、头围增长偏慢、要注意哦</view>
          <view class="fenge"></view>

          <view class="group3">
            <view class="group2">
              <view>身高</view>
              <view><text class="jilu-list-text2">{{item.height}}</text>cm</view>
            </view>
            <view class="group2">
              <view>体重</view>
              <view><text class="jilu-list-text2">{{item.weight}}</text>kg</view>
            </view>
            <view class="group2">
              <view>头围</view>
              <view><text class="jilu-list-text2">{{item.head}}</text>cm</view>
            </view>
          </view>
        </view>
      </view>

    </view>

    <!--身高曲线-->
    <view v-if="current == 1">
      <view class="charts-box">
        <qiun-data-charts type="line" :opts="opts" :chartData="chartData" :tooltipCustom="{x:0,y:10}" />
      </view>
    </view>

    <!--体重曲线-->
    <view v-if="current == 2">
      <view class="charts-box">
        <qiun-data-charts type="line" :opts="opts" :chartData="chartData" :tooltipCustom="{x:0,y:10}" />
      </view>
    </view>

    <!--头围曲线-->
    <view v-if="current == 3">
      <view class="charts-box">
        <qiun-data-charts type="line" :opts="opts" :chartData="chartData" :tooltipCustom="{x:0,y:10}" />
      </view>
    </view>

  </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        chartData: {},
        opts: {
          color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4", "#ea7ccc"],
          padding: [15, 10, 0, 15],
          dataPointShape: false,
          enableScroll: false,
          legend: {},
          xAxis: {
            disableGrid: false
          },
          yAxis: {
            gridType: "dash",
            dashLength: 2,
            data: [{
              "min": 30,
              "max": 80,
            }]
          },
          extra: {
            line: {
              type: "curve",
              width: 2,
              activeType: "hollow",
              linearType: "custom"
            }
          }
        },

        list: [{
          name: '记录列表'
        }, {
          name: '身高曲线'
        }, {
          name: '体重曲线'
        }, {
          name: '头围曲线'
        }],
        current: 0,

        baby: [{

        }]
      }
    },
    onShow() {
      uni.request({
        url: 'http://192.168.236.203:9000/getAllH',
        data: this.baby,
        method: "GET",
        success: (res) => {
          this.baby = res.data
        }
      });
      this.getServerData();
    },
    methods: {
      back() {
        uni.switchTab({
          url: '/pages/my/my'
        })
      },

      change(index) {
        this.current = index;
      },

      addRecoder() {
        uni.navigateTo({
          url: '/pages/add-recorder/add-recorder'
        })
      },
      getServerData() {
        //模拟从服务器获取数据时的延时
        setTimeout(() => {
          //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
          let res = {
            categories: ["出生", "1个月", "2个月", "3个月", "4个月", "5个月", "半年"],
            series: [{
              name: "曲线",
              linearColor: [
                [
                  0,
                  "#1890FF"
                ],
                [
                  0.25,
                  "#00B5FF"
                ],
                [
                  0.5,
                  "#00D1ED"
                ],
                [
                  0.75,
                  "#00E6BB"
                ],
                [
                  1,
                  "#90F489"
                ]
              ],
              data: [30, 32, 38, 40, 42, 45, 46]
            }]
          };
          this.chartData = JSON.parse(JSON.stringify(res));
          console.log(this.chartData)
        }, 500);
      },

    }
  }
</script>

<style>
  .top-box {
    display: flex;
    flex-direction: column;
    background-color: #d9d9d914;
    height: 1750rpx;
    width: 100%;
  }

  .top-item1 {
    display: flex;
    flex-direction: row;
  }

  .top-add {
    margin-left: 500rpx;
    background-color: #ff0b89;
    color: #fff;
    border-radius: 20px;
  }


  /**/
  .jilu-list {
    background-color: #fff;
    margin-top: 40rpx;
    margin-left: 40rpx;
    padding: 20rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 670rpx;
    height: 350rpx;
  }

  .jilu-list-item1 {
    margin-top: 20rpx;
    background-color: #94949414;
    padding: 20rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
  }

  .jilu-list-text1 {
    color: #ff0b89;
  }

  .fenge {
    margin: 20rpx 0;
    border-top: 2px solid #3a3a3a14;
  }

  .group3 {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
  }

  .group2 {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    width: 210rpx;
  }

  .jilu-list-text2 {
    color: #ff0b89;
    font-size: 40rpx;
  }

  /*身高曲线*/
  .charts-box {
    width: 100%;
    height: 1050rpx;
  }
</style>