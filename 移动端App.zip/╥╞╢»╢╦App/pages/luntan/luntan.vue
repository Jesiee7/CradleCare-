<template>
  <view class="rootView">
    <view class="biaoti">成长记录</view>
    <view class="touxiang-box">
      <u-avatar :src="yonghu.image" class="touxiang"></u-avatar>
      <view class="touxiang-item">
        <view class="touxiang-text1">{{yonghu.name}}</view>
        <view v-if="age_temp == ''"><u-button size="mini" @click="pop">宝贝今年多大啦</u-button></view>
        <view v-else>{{age_temp}}</view>
      </view>
    </view>


    <u-popup v-model="pop_show" width="600rpx" height="300px" closeable="true">
      <view class="popup">
        <u-form :model="yonghu" ref="uForm">
          <u-form-item label-width="140" label-position="left" label="年龄" prop="name">
            <u-input :border="border" placeholder="宝贝今年多大啦" v-model="age_temp" type="text"></u-input>
          </u-form-item>
        </u-form>
        <u-button @click="ageClick" class="submit">提交</u-button>
      </view>
    </u-popup>

    <!---->
    <u-tabs :list="list" :is-scroll="false" :current="current" @change="change" active-color="#ff0b89" class="tabs"
      bg-color="#f8f8f8"></u-tabs>

    <!--成长记录-->
    <view v-if="current == 0" class="chengzhang">
      <view class="chengzhang-item">
        <view class="chengzhang-item2">
          <image src="/static/chengzhang-cir.png" class="chengzhang-img1"></image>
          <view class="chengzhang-text1">2024-2-12</view>
        </view>
        <image src="../../static/pic1.png" class="chengzhang-img2"></image>
      </view>


      <view class="chengzhang-item" v-for="(item, index) in record.data" :key="index">
        <view class="chengzhang-item2">
          <image src="/static/chengzhang-cir.png" class="chengzhang-img1"></image>
          <view class="chengzhang-text1">{{item.time}}</view>
        </view>
        <view class="chengzhang-item3">
          {{item.msg}}
        </view>
      </view>
      <view class="navigation">
        <u-input :border="border" placeholder="今天宝宝有什么新鲜事呢,快来记录吧" v-model="mes" type="text"></u-input>
        <u-button size="medium" type="success" class="add" @click="addClick">提交</u-button>
      </view>
    </view>

    <!---->
    <view v-else-if="current == 1" class="xiangce">
      <view class="wrap" @click="chooseImage">
        <view class="box1">
          <image class="img2" src="/static/add-pic.png"></image>
          <view>添加图片</view>
        </view>


      </view>
      <image v-for="(image, index) in images" :src="image.name" :key="index" mode="aspectFit" class="img1"></image>

    </view>
  </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        yonghu: {
          image: '',
          age: '',
        },
        list: [{
          name: '成长记录'
        }, {
          name: '相册'
        }],
        current: 0,
        record: {
          msg: '',
          time: '',
        },
        mes: '',

        //
        images: [], // 存储选择的图片路径
        tep: '',

        //
        pop_show: false,
        token: '',
        //
        age_temp: '',
      };
    },
    onLoad() {
      const val = uni.getStorageSync('jwtToken')
      this.token = val
    },
    onShow() {
      try {
        const value = uni.getStorageSync('user')
        if (value) {
          if (!this.logined) { //从未登录变为登录
            this.yonghu = value
            console.log(value)
          }
          this.logined = true
        } else {
          this.logined = false
        }
      } catch (e) {
        // error
      }
      uni.request({
        url: 'http://192.168.236.203:9000/getRecord',
        data: {
          msg: this.record.msg,
          time: this.record.time,
        },
        method: "GET",
        success: (res) => {
          this.record = res.data
        }
      });
      uni.request({
        url: 'http://192.168.236.203:9000/showimg',
        data: {
          id: this.yonghu.id
        },
        method: "POST",
        success: (res) => {
          console.log(res)
          for (let i = 0; i < res.data.length; i++) {
            this.images.push({
              name: res.data[i].image,
            })
          }
        }
      });
      uni.request({
        url: 'http://localhost:9096/selectbaby',
        data: {
          id: this.yonghu.id
        },
        header: {
          'token': this.token
        },
        method: "POST",
        success: (res) => {
          console.log(res.data[0])
          if (res.data[0].age == 11) {
            return
          } else {
            this.age_temp = res.data[0].age
          }
        }
      });

    },
    methods: {
      pop() {
        this.pop_show = true
      },

      ageClick() {
        uni.request({
          url: 'http://localhost:9096/changebaby',
          data: {
            id: this.yonghu.id,
            age: this.age_temp,
          },
          header: {
            'token': this.token
          },
          method: "POST",
          success: (res) => {
            console.log(res)
            if (res.data.code * 1 == 1) {

              this.pop_show = false
            } else {
              this.$u.toast('输入错误')
            }

          }
        })
      },

      change(index) {
        this.current = index;
      },
      addClick() {
        if (this.mes == '') {
          this.$u.toast('内容为空')
        } else {
          uni.request({
            url: 'http://192.168.236.203:9000/newRecord',
            data: {
              msg: this.mes,
            },
            method: "POST",
            success: (res) => {
              console.log(res)
              uni.request({
                url: 'http://192.168.236.203:9000/getRecord',
                data: {
                  msg: this.record.msg,
                  time: this.record.time,
                },
                method: "GET",
                success: (res) => {
                  this.record = res.data
                  this.mes = ''
                }
              })
            }
          })
        }
      },

      //
      chooseImage() {
        uni.chooseImage({
          count: 1, // 图片数量，这里设置为1
          sizeType: ['original', 'compressed'], // 指定选择的图片类型，可以选择原图和压缩图，这里设置为二者都有
          sourceType: ['album', 'camera'], // 指定选择图片的来源，这里设置为相册和相机
          success: (res) => {
            console.log(res)
            this.tep = res.tempFilePaths[0]
            this.images.push({
              name: this.tep,
            })
            uni.uploadFile({
              url: 'http://192.168.236.203:9000/uploadimg',
              filePath: res.tempFilePaths[0],
              formData: {
                id: this.yonghu.id
              },
              name: 'image',
              success: (res) => {
                console.log('1')
              }
            });
          },
          fail: (err) => {
            console.log('选择图片失败', err);
          }
        });
      }



    },
  };
</script>

<style lang="scss" scoped>
  page {
    height: 100%;
    width: 100%;
    background-image: url('../../static/background.png');
  }

  .biaoti {
    margin-top: 40rpx;
    margin-bottom: 30rpx;
    font-size: 40rpx;
    font-weight: 800;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .touxiang-box {
    display: flex;
    flex-direction: row;
    background-color: #fff;
    margin-top: 50rpx;
    margin-left: 30rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 690rpx;
    height: 150rpx;
  }

  .touxiang {
    margin-left: 50rpx;
  }

  .touxiang-item {
    margin-left: 50rpx;
    display: flex;
    flex-direction: column;
  }

  .touxiang-text1 {
    margin-bottom: 15rpx;
    font-size: 40rpx;
    font-weight: bold;
  }

  /**/
  .tabs {
    margin-top: 10rpx;
  }

  /**/
  .chengzhang {
    width: 100%;
    background-color: #f8f8f8;
  }

  .chengzhang-item {
    margin: 0 35rpx;
    padding: 30rpx 0;
  }

  .chengzhang-item2 {
    display: flex;
    flex-direction: row;
  }

  .chengzhang-img1 {
    width: 22rpx;
    height: 22rpx;
    padding-top: 8rpx;
  }

  .chengzhang-text1 {
    margin-left: 20rpx;
  }

  .chengzhang-img2 {
    margin-top: 20rpx;
    width: 686rpx;
    height: 352rpx;
  }

  .chengzhang-item3 {
    padding: 30rpx 30rpx;
    width: 686rpx;
    height: 100rpx;
    margin-top: 20rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    background-color: #fff;
  }

  /**/
  .navigation {
    margin-top: 100rpx;
    width: 100%;
    height: 100rpx;
    min-height: 98rpx;
    background: #fff;
    position: fixed;
    bottom: 80rpx;
    display: flex;
    box-sizing: content-box;
    padding: 20rpx 30rpx;
  }

  .rootView {
    height: 88vh;
    overflow: auto;
  }

  .add {
    margin-right: 50rpx;
  }

  /**/

  .xiangce {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    align-items: center;
  }

  .wrap {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    margin-top: 50rpx;
    margin-left: 30rpx;
    margin-bottom: 40rpx;
    padding: 30rpx 0;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 650rpx;
    height: 400rpx;
  }

  .img1 {
    width: 300rpx;
    height: 400rpx;
  }

  .img2 {
    width: 140rpx;
    height: 140rpx;
    margin-bottom: 40rpx;
  }

  .box1 {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
  }
</style>