<template>
  <view>
    <image src="../../static/sunshine.png" class="img1"></image>
    <view class="group3">

      <view class="group2">
        <view>风</view>
        <view>东南风2级</view>
      </view>
      <view class="group2">
        <view>温度</view>
        <view>30℃</view>
      </view>
      <view class="group2">
        <view>湿度</view>
        <view>60%</view>
      </view>
    </view>


    <view class="text2">空气质量提示</view>
    <view class="group4">
      <view class="box1">
        <view class="box-text1">31</view>
        <view class="box-text2">优</view>
      </view>
      <view>空气质量令人满意，基本无空气污染</view>


      <view class="box2">
        <view class="box-group2">
          <view class="box2-text1">PM2.5</view>
          <view class="box2-text2">20</view>
        </view>
        <view class="box-group2">
          <view class="box2-text1">NO2</view>
          <view class="box2-text2">7</view>
        </view>
        <view class="box-group2">
          <view class="box2-text1">O3</view>
          <view class="box2-text2">31</view>
        </view>
      </view>

      <view class="box2">
        <view class="box-group2">
          <view class="box2-text1">PM10</view>
          <view class="box2-text2">21</view>
        </view>
        <view class="box-group2">
          <view class="box2-text1">CO</view>
          <view class="box2-text2">5</view>
        </view>
        <view class="box-group2">
          <view class="box2-text1">SO2</view>
          <view class="box2-text2">2</view>
        </view>
      </view>

    </view>

    <view class="text2">24小时空气质量预报</view>
    <view class="charts-box">
      <qiun-data-charts type="line" :opts="opts" :chartData="chartData" />
    </view>


  </view>
</template>

<script>
  export default {
    data() {
      return {
        chartData: {},
        opts: {
          color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4", "#ea7ccc"],
          padding: [15, 10, 0, 15],
          enableScroll: false,
          legend: {},
          xAxis: {
            disableGrid: true
          },
          yAxis: {
            gridType: "dash",
            dashLength: 2,
            data: [{
              "min": 40,
              "max": 120,
            }]
          },
          extra: {
            line: {
              type: "straight",
              width: 2,
              activeType: "hollow"
            }
          }
        }
      };
    },
    onReady() {
      this.getServerData();
    },
    methods: {
      getServerData() {
        //模拟从服务器获取数据时的延时
        setTimeout(() => {
          //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
          let res = {
            categories: ["16:00", "20:00", "00:00", "04:00", "08:00", "12:00"],
            series: [{
              name: '天气',
              linearColor: [
                [
                  0,
                  "#1890FF"
                ],
                [
                  0.25,
                  "#00B5FF"
                ],
                [
                  0.5,
                  "#00D1ED"
                ],
                [
                  0.75,
                  "#00E6BB"
                ],
                [
                  1,
                  "#90F489"
                ]
              ],
              data: [78, 80, 88, 90, 100, 111, 118, 98, 90, 78, 67, 56, 44, 34, 36, 37, 56]
            }]
          };
          this.chartData = JSON.parse(JSON.stringify(res));
          console.log(this.chartData)
        }, 500);
      },
    }
  };
</script>

<style scoped lang="scss">
  page {
    padding-top: 50rpx;
    background-color: #fff;
    height: 1750rpx;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    background-image: url('../../static/background.png');
  }

  .group1 {
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-direction: column;
    margin: 50rpx 40rpx;
    padding: 14rpx 28rpx 44rpx;
    background: #5B1BED;
    border-radius: 20rpx;

  }

  .img1 {
    margin-left: 200rpx;
    width: 326rpx;
    height: 300rpx;
  }

  .text1 {
    margin: 30rpx 0;
    display: flex;
    align-items: center;
    color: #fff;
    font-size: 70rpx;
  }

  .image_2 {
    margin-left: 200rpx;
    filter: blur(7rpx);
    width: 128rpx;
    height: 128rpx;
  }

  .text2 {
    line-height: 38rpx;
    margin: 20rpx;
    font-size: large;
    padding-left: 15rpx;
    display: flex;
    align-items: center;
    border-left: 3px solid rgb(47, 159, 233);
  }

  .group3 {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    color: #787878;
    font-size: 40rpx;
    font-weight: bold;
  }

  .group2 {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    width: 210rpx;
    height: 150rpx;
  }

  .group4 {
    display: flex;
    flex-direction: column;
    background-color: #fff;
    margin-top: 50rpx;
    margin-bottom: 50rpx;
    margin-left: 60rpx;
    padding: 30rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 630rpx;
    height: 550rpx;
  }


  /**/
  .box1 {
    display: flex;
    flex-direction: row;
    color: #00c700;
    margin-bottom: 20rpx;
  }

  .box-text1 {
    font-weight: bold;
    font-size: 80rpx;
  }

  .box-text2 {
    font-size: 32rpx;
    margin-left: 20rpx;
    margin-top: 45rpx;
  }

  .box2 {
    display: flex;
    flex-direction: row;
    padding-right: 30rpx;
  }

  .box-group2 {
    margin-top: 30rpx;
    display: flex;
    flex-direction: column;
    width: 240rpx;
    height: 150rpx;
  }

  .box2-text1 {
    font-size: 30rpx;
    color: #a6a6a6;
    font-weight: bold;
  }

  .box2-text2 {
    font-size: 30rpx;
    margin-left: 10rpx;
  }
</style>