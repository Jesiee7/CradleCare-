<template>
  <view>
    <!-- 根据if的判断显示不同的界⾯ -->
    <view v-if="logined">
      <view class="top-box">
        <view class="login">
          <u-avatar :src="yonghu.image" class="top_img"></u-avatar>
          <view>{{yonghu.name}}</view>
        </view>
      </view>

      <view class="box" v-if="yonghu.type == 'super'">
        <u-cell-group :border="false">
          <u-cell-item icon="/static/微信图片_20240416161119.png" title="管理用户" @click="adminClick" :border-bottom="false">
          </u-cell-item>
          <u-cell-item icon="/static/微信图片_202404161611341.png" title="相册" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_202404161611342.png" title="卡券" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_20240416161134.png" title="关注" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_20240416161135.png" title="退出" @click="quit()" :border-bottom="false">

          </u-cell-item>
        </u-cell-group>
      </view>

      <view class="box" v-else>
        <u-cell-group :border="false">
          <u-cell-item icon="/static/微信图片_202404161611341.png" title="相册" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_202404161611342.png" title="卡券" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_20240416161134.png" title="关注" :border-bottom="false">

          </u-cell-item>
          <u-cell-item icon="/static/微信图片_20240416161135.png" title="退出" @click="quit()" :border-bottom="false">

          </u-cell-item>
        </u-cell-group>
      </view>


      <!--新增-->
      <view class="box1">
        <view class="box1-text">发现</view>
        <u-grid :col="3" class="grid" :border="false">
          <u-grid-item>
            <image class="box1-img" @click="eatClick" src="../../static/微信图片_20240416154040.png"></image>
            <view class="grid-text">能不能吃</view>
          </u-grid-item>
          <u-grid-item>
            <image class="box1-img" @click="market" src="/static/微信图片_202404161541002.png"></image>
            <view class="grid-text">商城</view>
          </u-grid-item>
          <u-grid-item>
            <image class="box1-img" @click="shengao" src="/static/微信图片_20240416154101.png"></image>
            <view class="grid-text">身高体重</view>
          </u-grid-item>
          <u-grid-item>
            <image class="box1-img" @click="yimiaoClick" src="/static/微信图片_202404161541001.png"></image>
            <view class="grid-text">疫苗</view>
          </u-grid-item>
          <u-grid-item>
            <image class="box1-img" @click="tieClick" src="/static/微信图片_20240416154100.png"></image>
            <view class="grid-text">辣妈圈</view>
          </u-grid-item>
          <u-grid-item>
            <image class="box1-img" src="/static/微信图片_20240416161221.png"></image>
            <view class="grid-text" @click="hh">待添加</view>
          </u-grid-item>
        </u-grid>
      </view>

    </view>
    <!-- else处理,如果没有登录那么我不显示具体的微信跟相关信息 -->


    <view v-else>
      <view class="top-box">
        <view class="login">
          <image src="/static/xiaolian.png" class="top_img"></image>
        </view>
      </view>

      <view class="box">
        <u-cell-group :border="false">
          <!-- 图标集https://www.uviewui.com/components/icon.html -->
          <u-cell-item icon="man-add" title="登录" @click="goLogin" :border-bottom="false"></u-cell-item>
        </u-cell-group>
      </view>
    </view>
  </view>

</template>

<script>
  export default {
    data() {
      return {
        pic: '/uview-ui/components/u-avatar-cropper/u-avatar-cropper',
        //定义⼀个变量
        logined: false,
        yonghu: {
          name: "游客",
          image: '',
        },
        img: '',
      }
    },
    onLoad() {},
    onShow() {
      try {
        const value = uni.getStorageSync('user')
        if (value) {
          if (!this.logined) { //从未登录变为登录
            this.yonghu = value
            console.log(value)
          }
          this.logined = true
        } else {
          this.logined = false
        }
      } catch (e) {
        // error
      }
    },
    methods: {
      goLogin() {
        uni.navigateTo({
          url: '/pages/login/login'
        })
      },
      quit() { //增加
        uni.setStorageSync("user", ""); //清空 存储
        this.logined = false //登陆状态
        uni.setStorageSync("jwtToken", ""); //清空 存储
      },
      adminClick() {
        uni.navigateTo({
          url: '/pages/admin/admin'
        })
      },
      shengao() {
        uni.navigateTo({
          url: '/pages/shengaojilu/shengaojilu'
        })
      },
      market() {
        uni.navigateTo({
          url: '/pages/market/market'
        })
      },
      eatClick() {
        uni.navigateTo({
          url: '/pages/eat/eat'
        })
      },
      yimiaoClick() {
        uni.navigateTo({
          url: '/pages/index/index'
        })
      },
      tieClick() {
        uni.navigateTo({
          url: '/pages/tiezi/tiezi'
        })
      },
      hh() {
        uni.navigateTo({
          url: '/pages/index2/index2'
        })
      }
    }
  }
</script>

<style>
  page {
    background: #fff;
  }

  .top-box {
    width: 100%;
    height: 250rpx;
    background-color: #428de2;
    border-radius: 0 0 30px 30px / 0 0 30px 30px;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .login {
    margin-top: 80rpx;
    border: 1rpx solid #fff;
    background-color: #fff;
    width: 710rpx;
    height: 270rpx;
    border-radius: 20px 20px 20px 20px / 20px 20px 20px 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    box-shadow: 0 4px 5px rgb(143, 185, 206);
  }

  .top_img {
    padding-top: 20rpx;
    width: 100rpx;
    height: 100rpx;
  }

  .box {
    margin-top: 100rpx;
    display: flex;
    flex-direction: column;
    background-color: #fff;
    margin-left: 30rpx;
    padding: 10rpx 20rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 690rpx;
    height: 100%;
  }

  .box-img {
    width: 30rpx;
    height: 30rpx;
  }

  /**/
  .box1 {
    display: flex;
    flex-direction: column;
    background-color: #fff;
    margin-top: 50rpx;
    margin-left: 30rpx;
    padding: 10rpx 20rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 690rpx;
    height: 100%;
  }

  .box1-text {
    font-size: 40rpx;
    font-weight: bold;
    margin-left: 30rpx;
    margin-top: 20rpx;
  }

  .box1-img {
    width: 60rpx;
    height: 60rpx;
  }

  .grid {
    margin-top: 40rpx;
  }

  .grid-text {
    font-size: 28rpx;
    margin-top: 4rpx;
    color: $u-type-info;
  }
</style>