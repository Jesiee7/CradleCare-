<template>
  <view class="flex-col page">
    <text class="self-start font text">出生</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_1">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_2 ml-29">卡介苗</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_1">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_58">{{ data1 }}</text>

            <u-calendar v-model="show1" :mode="mode1" @change="change1"></u-calendar>

            <u-button size="mini" @click="show1 = true"><text class="font_3 text_5">修改</text></u-button>

          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_53">完成接种</text>
          <view class="ml-27">
            <checkbox :value="isChecked1" @change="onCheckboxChange1"></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_3 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_7 ml-29">乙肝疫苗（一）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data2 }}</text>

            <u-calendar v-model="show2" :mode="mode2" @change="change2"></u-calendar>
            <u-button size="mini" @click="show2 = true"><text class="font_3 text_5">修改</text></u-button>

          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_3 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_8 ml-29">乙肝疫苗（二）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data3 }}</text>

            <u-calendar v-model="show3" :mode="mode3" @change="change3"></u-calendar>
            <u-button size="mini" @click="show3 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">2月龄</text>
    <view class="mt-28 flex-col self-stretch section_3">
      <view class="flex-row">
        <text class="font_2">疫苗名称</text>
        <text class="ml-28 font_2 text_9">脊灰灭活疫苗（一）</text>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_3">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_4">{{ data4 }}</text>

          <u-calendar v-model="show4" :mode="mode4" @change="change4"></u-calendar>
          <u-button size="mini" @click="show4 = true"><text class="font_3 text_5">修改</text></u-button>

        </view>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_6">完成接种</text>
        <view class="section ml-27">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">3月龄</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_3">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_14">脊灰灭活疫苗（二）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data5 }}</text>
            <u-calendar v-model="show5" :mode="mode5" @change="change5"></u-calendar>
            <u-button size="mini" @click="show5 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_3 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <view class="flex-col justify-start relative ml-29">
            <text class="font_2 text_15">百日破疫苗（一）</text>
            <text class="font_2 text_16 pos">百日破疫苗（一</text>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data6 }}</text>
            <u-calendar v-model="show6" :mode="mode6" @change="change6"></u-calendar>
            <u-button size="mini" @click="show6 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">4月龄</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_3">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <view class="flex-col justify-start relative ml-29">
            <text class="font_2 text_15">百日破疫苗（二）</text>
            <text class="font_2 text_16 pos_2">百日破疫苗（</text>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data7 }}</text>

            <u-calendar v-model="show7" :mode="mode7" @change="change7"></u-calendar>
            <u-button size="mini" @click="show7 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_3 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_17">脊灰减毒活疫苗（一）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_3">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_4">{{ data8 }}</text>
            <u-calendar v-model="show8" :mode="mode8" @change="change8"></u-calendar>
            <u-button size="mini" @click="show8 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_6">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">5月龄</text>
    <view class="mt-28 flex-col self-stretch section_3">
      <view class="flex-row">
        <text class="font_2">疫苗名称</text>
        <text class="font_2 text_18 ml-29">百日破疫苗（三）</text>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_3">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_4">{{ data9 }}</text>
          <u-calendar v-model="show9" :mode="mode9" @change="change9"></u-calendar>
          <u-button size="mini" @click="show9 = true"><text class="font_3 text_5">修改</text></u-button>
        </view>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_6">完成接种</text>
        <view class="section ml-27">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font text_54">6月龄</text>
    <view class="mt-28 flex-col self-stretch section_2">
      <view class="flex-row">
        <text class="font_2">疫苗名称</text>
        <text class="ml-28 font_2 text_60">A群流脑多糖疫苗（一）</text>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_10">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_11">{{ data10 }}</text>
          <u-calendar v-model="show10" :mode="mode10" @change="change10"></u-calendar>
          <u-button size="mini" @click="show10 = true"><text class="font_3 text_5">修改</text></u-button>
        </view>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_13">完成接种</text>
        <view class="section ml-27">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">8月龄</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_11">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_29">麻腮风疫苗（一）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data11 }}</text>
            <u-calendar v-model="show11" :mode="mode11" @change="change11"></u-calendar>
            <u-button size="mini" @click="show11 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_11 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_29 ml-29">乙脑减毒活疫苗（一）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data12 }}</text>
            <u-calendar v-model="show12" :mode="mode12" @change="change12"></u-calendar>
            <u-button size="mini" @click="show12 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font">9月龄</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_11">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_29 ml-29">乙肝疫苗（三）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data13 }}</text>
            <u-calendar v-model="show13" :mode="mode13" @change="change13"></u-calendar>
            <u-button size="mini" @click="show13 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_11 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_29">A群流脑多糖疫苗（二）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data14 }}</text>
            <u-calendar v-model="show14" :mode="mode14" @change="change14"></u-calendar>
            <u-button size="mini" @click="show14 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font text_55">18月龄</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_11">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="font_2 text_29 ml-29">百日破疫苗（四）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data15 }}</text>

            <u-calendar v-model="show15" :mode="mode15" @change="change15"></u-calendar>
            <u-button size="mini" @click="show15 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_11 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_29">麻腮风疫苗（一）</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_19">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_20">{{ data16 }}</text>

            <u-calendar v-model="show16" :mode="mode16" @change="change16"></u-calendar>
            <u-button size="mini" @click="show16 = true"><text class="font_3 text_5">修改</text></u-button>

          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_22">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col list-item_1 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-30 font_2 text_28">甲肝减毒活疫苗</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_61">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_33">{{ data17 }}</text>

            <u-calendar v-model="show17" :mode="mode17" @change="change17"></u-calendar>
            <u-button size="mini" @click="show17 = true"><text class="font_3 text_5">修改</text></u-button>

          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_57">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font_4">2周岁</text>
    <view class="mt-28 flex-col self-stretch section_11">
      <view class="flex-row">
        <text class="font_2">疫苗名称</text>
        <text class="font_2 text_29 ml-29">乙脑减毒活疫苗（二）</text>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_19">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_20">{{ data18 }}</text>

          <u-calendar v-model="show18" :mode="mode18" @change="change18"></u-calendar>
          <u-button size="mini" @click="show18 = true"><text class="font_3 text_5">修改</text></u-button>
        </view>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_22">完成接种</text>
        <view class="section ml-27">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font_4">3周岁0.5个月</text>
    <view class="mt-28 flex-col self-stretch section_5">
      <view class="flex-row self-stretch">
        <text class="font_2">疫苗名称</text>
        <text class="ml-28 font_2 text_30">A群C群流脑多糖疫苗（一）</text>
      </view>
      <view class="flex-row items-center self-stretch group mt-17">
        <text class="font_2 text_37">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_38">{{ data19 }}</text>

          <u-calendar v-model="show19" :mode="mode19" @change="change19"></u-calendar>
          <u-button size="mini" @click="show19 = true"><text class="font_3 text_5">修改</text></u-button>
        </view>
      </view>
      <view class="flex-row justify-between items-center self-start group_2 mt-17">
        <text class="font_2 text_34">完成接种</text>
        <view class="section">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font_4">4周岁0.5个月</text>
    <view class="mt-28 flex-col self-stretch section_6">
      <view class="flex-row">
        <text class="font_2">疫苗名称</text>
        <text class="ml-28 font_2 text_35">脊灰减毒活疫苗（二）</text>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_42">接种时间</text>
        <view class="ml-28 flex-row items-center flex-1">
          <text class="font_2 text_43">{{ data20 }}</text>

          <u-calendar v-model="show20" :mode="mode20" @change="change20"></u-calendar>
          <u-button size="mini" @click="show20 = true"><text class="font_3 text_5">修改</text></u-button>
        </view>
      </view>
      <view class="flex-row items-center mt-17">
        <text class="font_2 text_45">完成接种</text>
        <view class="section ml-27">
          <checkbox></checkbox>
        </view>
      </view>
    </view>
    <text class="mt-28 self-start font_4 text_46">6周岁0.5个月</text>
    <view class="mt-28 flex-col self-stretch">
      <view class="flex-col section_7">
        <view class="flex-row self-stretch">
          <text class="font_2">疫苗名称</text>
          <text class="ml-28 font_2 text_47">A群C群流脑多糖疫苗（二）</text>
        </view>
        <view class="flex-row items-center self-stretch group_3 mt-17">
          <text class="font_2 text_31">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_32">{{ data21 }}</text>

            <u-calendar v-model="show21" :mode="mode21" @change="change21"></u-calendar>
            <u-button size="mini" @click="show21 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row justify-between items-center self-start group_2 mt-17">
          <text class="font_2 text_34">完成接种</text>
          <view class="section">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
      <view class="flex-col section_8 mt-25">
        <view class="flex-row">
          <text class="font_2">疫苗名称</text>
          <text class="ml-30 font_2">白破疫苗</text>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_62">接种时间</text>
          <view class="ml-28 flex-row items-center flex-1">
            <text class="font_2 text_63">{{ data22 }}</text>

            <u-calendar v-model="show22" :mode="mode22" @change="change22"></u-calendar>
            <u-button size="mini" @click="show22 = true"><text class="font_3 text_5">修改</text></u-button>
          </view>
        </view>
        <view class="flex-row items-center mt-17">
          <text class="font_2 text_51">完成接种</text>
          <view class="section ml-27">
            <checkbox></checkbox>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
  export default {
    components: {},
    prop: {

    },
    data() {
      return {
        show1: false,
        mode1: 'date',
        show2: false,
        mode2: 'date',
        show3: false,
        mode3: 'date',
        show4: false,
        mode4: 'date',
        show5: false,
        mode5: 'date',
        show6: false,
        mode6: 'date',
        show7: false,
        mode7: 'date',
        show8: false,
        mode8: 'date',
        show9: false,
        mode9: 'date',
        show10: false,
        mode10: 'date',
        show11: false,
        mode11: 'date',
        show12: false,
        mode12: 'date',
        show13: false,
        mode13: 'date',
        show14: false,
        mode14: 'date',
        show15: false,
        mode15: 'date',
        show16: false,
        mode16: 'date',
        show17: false,
        mode17: 'date',
        show18: false,
        mode18: 'date',
        show19: false,
        mode19: 'date',
        show20: false,
        mode20: 'date',
        show21: false,
        mode21: 'date',
        show22: false,
        mode22: 'date',
        isChecked1: false,
        data1: '',
        data2: '',
        data3: '',
        data4: '',
        data5: '',
        data6: '',
        data7: '',
        data8: '',
        data9: '',
        data10: '',
        data11: '',
        data12: '',
        data13: '',
        data14: '',
        data15: '',
        data16: '',
        data17: '',
        data18: '',
        data19: '',
        data20: '',
        data21: '',
        data22: '',

      };
    },
    onShow() {
      this.isChecked1 = uni.getStorageSync('checkboxChecked') || false;
    },
    methods: {
      onCheckboxChange1(event) {
        this.isChecked = event.detail.value;
        uni.setStorageSync('checkboxChecked', this.isChecked1);
      },
      change1(e1) {
        console.log(e1);
        this.data1 = e1.result;
      },
      change2(e2) {
        console.log(e2);
        this.data2 = e2.result;
      },
      change3(e3) {
        console.log(e3);
        this.data3 = e3.result;
      },
      change4(e4) {
        console.log(e4);
        this.data4 = e4.result;
      },
      change5(e5) {
        console.log(e5);
        this.data5 = e5.result;
      },
      change6(e6) {
        console.log(e6);
        this.data6 = e6.result;
      },
      change7(e7) {
        console.log(e7);
        this.data7 = e7.result;
      },
      change8(e8) {
        console.log(e8);
        this.data8 = e8.result;
      },
      change9(e9) {
        console.log(e9);
        this.data9 = e9.result;
      },
      change10(e10) {
        console.log(e10);
        this.data10 = e10.result;
      },
      change11(e11) {
        console.log(e11);
        this.data11 = e11.result;
      },
      change12(e12) {
        console.log(e12);
        this.data12 = e12.result;
      },
      change13(e13) {
        console.log(e13);
        this.data13 = e13.result;
      },
      change14(e14) {
        console.log(e14);
        this.data14 = e14.result;
      },
      change15(e15) {
        console.log(e15);
        this.data15 = e15.result;
      },
      change16(e16) {
        console.log(e16);
        this.data16 = e16.result;
      },
      change17(e17) {
        console.log(e17);
        this.data7 = e7.result;
      },
      change18(e18) {
        console.log(e18);
        this.data18 = e18.result;
      },
      change19(e19) {
        console.log(e19);
        this.data19 = e19.result;
      },
      change20(e20) {
        console.log(e20);
        this.data20 = e20.result;
      },
      change21(e21) {
        console.log(e21);
        this.data21 = e21.result;
      },
      change22(e22) {
        console.log(e22);
        this.data22 = e22.result;
      },



    },
  }
</script>

<style scoped lang="scss">
  page {}

  .ml-27 {
    margin-left: 27px;
  }

  .ml-29 {
    margin-left: 29px;
  }

  .mt-17 {
    margin-top: 17px;
  }

  .mt-25 {
    margin-top: 25px;
  }

  .page {
    padding: 45.5px 18px 57px 18px;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;
    position: fixed;
    background-image: url('/static/background.png');

    .font {
      font-size: 20px;
      font-family: SourceHanSansCN;
      line-height: 18.5px;
      color: #000000;
    }

    .text {
      margin-left: 2px;
      line-height: 18.5px;
    }

    .section_1 {
      padding: 30.5px 8.5px 33px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_2 {
        line-height: 16.5px;
      }

      .text_1 {
        line-height: 16.5px;
      }

      .text_58 {
        line-height: 16.5px;
      }

      .text_53 {
        line-height: 17px;
      }
    }

    .section_3 {
      padding: 30.5px 8.5px 33px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_7 {
        line-height: 17px;
      }

      .text_3 {
        line-height: 16.5px;
      }

      .text_4 {
        line-height: 16.5px;
      }

      .text_6 {
        line-height: 17px;
      }

      .text_8 {
        line-height: 17px;
      }

      .text-wrapper {
        padding: 3px 0 4px;
        background-color: #cccccc00;
        border-radius: 30px;
        height: 24px;
        border-left: solid 1px #000000;
        border-right: solid 1px #000000;
        border-top: solid 1px #000000;
        border-bottom: solid 1px #000000;
      }

      .text_9 {
        line-height: 17px;
      }

      .text_14 {
        line-height: 17px;
      }

      .text_15 {
        line-height: 17px;
      }

      .text_16 {
        line-height: 17px;
      }

      .pos {
        position: absolute;
        left: 0;
        bottom: 0;
      }

      .pos_2 {
        position: absolute;
        left: 0;
        bottom: 0;
      }

      .text_17 {
        line-height: 17px;
      }

      .text_18 {
        line-height: 17px;
      }
    }

    .font_2 {
      font-size: 18px;
      font-family: SourceHanSansCN;
      line-height: 16.5px;
      color: #000000;
    }

    .text-wrapper_1 {
      padding: 3px 0 4px;
      background-color: #cccccc00;
      border-radius: 30px;
      height: 24px;
      border-left: solid 1px #000000;
      border-right: solid 1px #000000;
      border-top: solid 1px #000000;
      border-bottom: solid 1px #000000;

      .text_5 {
        margin-left: 5px;
        margin-right: 1px;
      }
    }

    .section {
      background-color: #cccccc;
      border-radius: 50%;
      width: 21px;
      height: 23px;
    }

    .font_3 {
      font-size: 16px;
      font-family: HanaMin;
      line-height: 15px;
      color: #000000;
    }

    .text_52 {
      margin-left: 5px;
      margin-right: 1px;
    }

    .text_54 {
      margin-left: 1px;
    }

    .section_2 {
      padding: 30.5px 8.5px 33px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_60 {
        line-height: 17px;
      }

      .text_10 {
        line-height: 16.5px;
      }

      .text_11 {
        line-height: 16.5px;
      }

      .text_13 {
        line-height: 17px;
      }
    }

    .section_11 {
      padding: 33.5px 8.5px 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_29 {
        line-height: 17px;
      }

      .text_19 {
        line-height: 16.5px;
      }

      .text_20 {
        line-height: 16.5px;
      }

      .text_22 {
        line-height: 17px;
      }
    }

    .text-wrapper_3 {
      padding: 3px 0 4px;
      background-color: #cccccc00;
      border-radius: 30px;
      height: 24px;
      border-left: solid 1px #000000;
      border-right: solid 1px #000000;
      border-top: solid 1px #000000;
      border-bottom: solid 1px #000000;

      .text_23 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_59 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_56 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_39 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_44 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_64 {
        margin-left: 5px;
        margin-right: 1px;
      }

      .text_50 {
        margin-left: 5px;
        margin-right: 1px;
      }
    }

    .text_55 {
      margin-left: 2px;
    }

    .list-item_1 {
      padding: 33.5px 8.5px 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_28 {
        line-height: 16.5px;
      }

      .text_61 {
        line-height: 16.5px;
      }

      .text_33 {
        line-height: 16.5px;
      }

      .text_57 {
        line-height: 17px;
      }
    }

    .font_4 {
      font-size: 20px;
      font-family: SourceHanSansCN;
      line-height: 18.5px;
      color: #000000;
    }

    .section_5 {
      padding: 33.5px 0 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_30 {
        line-height: 17px;
      }

      .group {
        margin-right: 8.5px;

        .text_37 {
          line-height: 16.5px;
        }

        .text_38 {
          line-height: 16.5px;
        }
      }
    }

    .section_6 {
      padding: 33.5px 8.5px 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_35 {
        line-height: 17px;
      }

      .text_42 {
        line-height: 16.5px;
      }

      .text_43 {
        line-height: 16.5px;
      }

      .text_45 {
        line-height: 17px;
      }
    }

    .text_46 {
      margin-left: 1px;
    }

    .section_7 {
      padding: 33.5px 0 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_47 {
        line-height: 17px;
      }

      .group_3 {
        margin-right: 8.5px;

        .text_31 {
          line-height: 16.5px;
        }

        .text_32 {
          line-height: 16.5px;
        }
      }
    }

    .group_2 {
      width: 121px;

      .text_34 {
        line-height: 17px;
      }
    }

    .section_8 {
      padding: 33.5px 8.5px 30px 18.5px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 10rpx 8rpx 80rpx #00000014;

      .text_62 {
        line-height: 16.5px;
      }

      .text_63 {
        line-height: 16.5px;
      }

      .text_51 {
        line-height: 17px;
      }
    }
  }
</style>