<template>
  <view class="flex-col justify-start page">
    <view class="flex-col">
      <view class="flex-col justify-start group">
        <view class="flex-row group_2">
          <image class="self-center image" src="/static/微信图片_20240415175233.jpg" />
          <view class="ml-14 flex-col flex-1 self-start">
            <view class="flex-row items-baseline">
              <text class="font text">八宝粥</text>
              <text class="ml-22 font_2 text_2">高糖·高热量</text>
            </view>
            <view class="mt-14 flex-row">
              <image class="image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_46">哺乳</text>
              <image class="image_2 image_3" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_47">宝宝</text>
              <image class="image_2 image_4" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_45">月子</text>
              <image class="image_2 image_38" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_5">备孕</text>
              <image class="image_2 image_6" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2">孕期</text>
            </view>
          </view>
        </view>
      </view>
      <view class="flex-row items-start group_3">
        <image class="image_7" src="/static/微信图片_202404151752341.jpg" />
        <view class="ml-14 flex-col flex-1">
          <text class="self-start font text_7">全麦面包</text>
          <view class="mt-14 flex-row self-stretch">
            <image class="image_2" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_8">哺乳</text>
            <image class="self-center image_2 image_8" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_9">宝宝</text>
            <image class="image_2 image_10" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_10">月子</text>
            <image class="image_2 image_36" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_11">备孕</text>
            <image class="image_2 image_11" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2">孕期</text>
          </view>
        </view>
      </view>
      <view class="flex-col justify-start">
        <view class="flex-row group_4">
          <image class="self-center image_12" src="/static/微信图片_202404151752342.jpg" />
          <view class="ml-14 flex-col flex-1 self-start">
            <text class="self-start font text_12">魔芋</text>
            <view class="flex-row self-stretch mt-17">
              <image class="image_2 image_37" src="/static/微信图片_202404151752331.jpg" />
              <text class="self-center font_2 text_3">哺乳</text>
              <image class="self-center image_2 image_13" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_4">宝宝</text>
              <image class="self-center image_2 image_15" src="/static/微信图片_202404151752331.jpg" />
              <text class="self-center font_2 text_1">月子</text>
              <image class="image_2 image_1" src="/static/微信图片_202404151752331.jpg" />
              <text class="self-center font_2 text_13">备孕</text>
              <image class="self-center image_2 image_14" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2">孕期</text>
            </view>
          </view>
        </view>
      </view>
      <view class="flex-row items-center group_5">
        <image class="image_16" src="/static/微信图片_202404151752343.jpg" />
        <view class="flex-col items-start flex-1">
          <text class="font text_14">韭菜花</text>
          <view class="mt-8 flex-row equal-division">
            <view class="flex-row items-center group_6 equal-division-item">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_48">哺乳</text>
            </view>
            <view class="ml-14 flex-row items-center group_6 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_49">宝宝</text>
            </view>
            <view class="ml-14 flex-row items-center group_6 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="font_2 text_50">月子</text>
            </view>
            <view class="ml-14 flex-row items-center group_6 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_51">备孕</text>
            </view>
            <view class="ml-14 flex-row items-center group_6 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="font_2">孕期</text>
            </view>
          </view>
        </view>
      </view>
      <view class="flex-col group_7">
        <view class="flex-row">
          <image class="image_17" src="/static/微信图片_202404151752344.jpg" />
          <view class="flex-col group_8 ml-13">
            <text class="self-start font text_15">白果</text>
            <view class="mt-14 flex-row self-stretch">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_16">哺乳</text>
              <image class="shrink-0 image_2 image_18" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_43">宝宝</text>
              <image class="shrink-0 image_2 image_19" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_44">月子</text>
              <image class="shrink-0 image_2 image_5" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2 text_26">备孕</text>
              <image class="shrink-0 image_2 image_20" src="/static/微信图片_202404151752332.jpg" />
              <text class="self-center font_2">孕期</text>
            </view>
          </view>
        </view>
        <view class="mt-28 flex-col justify-start group_1">
          <view class="flex-row">
            <image class="image_22" src="/static/微信图片_20240415175235.jpg" />
            <view class="ml-10 flex-col group_9">
              <text class="self-start font text_17">猪油</text>
              <view class="flex-row self-stretch mt-15">
                <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
                <text class="self-center font_2 text_18">哺乳</text>
                <image class="shrink-0 image_2 image_25" src="/static/微信图片_202404151752332.jpg" />
                <text class="self-center font_2 text_19">宝宝</text>
                <image class="shrink-0 image_2 image_23" src="/static/微信图片_202404151752332.jpg" />
                <text class="self-center font_2 text_30">月子</text>
                <image class="shrink-0 image_2 image_24" src="/static/微信图片_202404151752332.jpg" />
                <text class="self-center font_2 text_20">备孕</text>
                <image class="shrink-0 image_2 image_26" src="/static/微信图片_202404151752332.jpg" />
                <text class="self-center font_2 text_21">孕期</text>
              </view>
            </view>
          </view>
        </view>
      </view>
      <view class="flex-row group_10">
        <image class="image_27" src="/static/微信图片_20240415175037.jpg" />
        <view class="flex-col items-start flex-1">
          <text class="font text_22">当归</text>
          <view class="mt-8 flex-row equal-division_2">
            <view class="flex-row items-center group_11 equal-division-item">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_34">哺乳</text>
            </view>
            <view class="ml-14 flex-row items-center group_11 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_35">宝宝</text>
            </view>
            <view class="ml-14 flex-row items-center group_11 equal-division-item">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="font_2 text_36">月子</text>
            </view>
            <view class="ml-14 flex-row items-center group_11 equal-division-item">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="ml-2 font_2 text_37">备孕</text>
            </view>
            <view class="ml-14 flex-row items-center group_11 equal-division-item_2">
              <image class="shrink-0 image_2" src="/static/微信图片_202404151752332.jpg" />
              <text class="font_2">孕期</text>
            </view>
          </view>
        </view>
      </view>
      <view class="flex-row group_12">
        <image class="self-start image_28" src="/static/e98e3ae759d54d7f434ac0fe168886f.jpg" />
        <view class="flex-col flex-1 self-center ml-13">
          <text class="self-start font text_23">黑芝麻</text>
          <view class="mt-14 flex-row self-stretch">
            <image class="image_2" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_24">哺乳</text>
            <image class="self-center image_2 image_29" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_25">宝宝</text>
            <image class="image_2 image_30" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_41">月子</text>
            <image class="image_2 image_35" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2 text_42">备孕</text>
            <image class="image_2 image_33" src="/static/微信图片_202404151752331.jpg" />
            <text class="self-center font_2">孕期</text>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
  export default {
    components: {},
    props: {},
    data() {
      return {};
    },

    methods: {},
  };
</script>

<style scoped lang="scss">
  page {
    background-image: url('/static/background.png');
  }

  .mt-17 {
    margin-top: 17px;
  }

  .ml-13 {
    margin-left: 13px;
  }

  .mt-15 {
    margin-top: 15px;
  }

  .page {
    padding-bottom: 112.5px;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;

    .group {
      padding-top: 22px;

      .group_2 {
        padding: 28px 12px 7px;

        .image {
          width: 59px;
          height: 62px;
        }

        .text {
          line-height: 16.5px;
        }

        .text_2 {
          color: #a19f9f;
          line-height: 10px;
        }

        .text_46 {
          line-height: 10px;
        }

        .image_3 {
          margin-left: 15px;
        }

        .text_47 {
          margin-left: 1.5px;
          line-height: 10px;
        }

        .image_4 {
          margin-left: 17.5px;
        }

        .text_45 {
          line-height: 9.5px;
        }

        .image_38 {
          margin-left: 12px;
        }

        .text_5 {
          margin-left: 2.5px;
          line-height: 10px;
        }

        .image_6 {
          margin-left: 12.5px;
        }
      }
    }

    .group_3 {
      padding: 28px 12px 0;

      .image_7 {
        margin-top: 7.5px;
        width: 59px;
        height: 60px;
      }

      .text_7 {
        line-height: 17px;
      }

      .text_8 {
        line-height: 10px;
      }

      .image_8 {
        margin-left: 16px;
      }

      .text_9 {
        line-height: 10px;
      }

      .image_10 {
        margin-left: 15.5px;
        margin-top: 2px;
      }

      .text_10 {
        line-height: 9.5px;
      }

      .image_36 {
        margin-left: 13px;
      }

      .text_11 {
        margin-left: 1.5px;
        line-height: 10px;
      }

      .image_11 {
        margin-left: 12.5px;
      }
    }

    .font {
      font-size: 18px;
      font-family: SourceHanSansCN;
      line-height: 16.5px;
      color: #000000;
    }

    .image_2 {
      width: 19px;
      height: 19px;
    }

    .font_2 {
      font-size: 11px;
      font-family: SourceHanSansCN;
      line-height: 10px;
      color: #000000;
    }

    .group_4 {
      padding: 28.5px 14px 13px 14px;

      .image_12 {
        width: 57px;
        height: 61px;
      }

      .text_12 {
        margin-left: 1.5px;
        line-height: 16.5px;
      }

      .image_37 {
        margin-top: 2px;
      }

      .text_3 {
        line-height: 10px;
      }

      .image_13 {
        margin-left: 17px;
      }

      .text_4 {
        line-height: 10px;
      }

      .image_15 {
        margin-left: 15.5px;
      }

      .text_1 {
        line-height: 9.5px;
      }

      .image_1 {
        margin-left: 11px;
        margin-top: 2px;
      }

      .text_13 {
        margin-left: 3.5px;
        line-height: 10px;
      }

      .image_14 {
        margin-left: 12.5px;
      }
    }

    .group_5 {
      padding: 31px 14px 10.5px;

      .image_16 {
        width: 57px;
        height: 59px;
      }

      .text_14 {
        margin-left: 14px;
        line-height: 16.5px;
      }

      .equal-division {
        padding-left: 14px;
        padding-right: 10px;
        width: 292px;

        .group_6 {
          flex: 1 1 42.5px;

          .text_48 {
            line-height: 10px;
          }

          .text_49 {
            line-height: 10px;
          }

          .text_50 {
            line-height: 9.5px;
          }

          .text_51 {
            line-height: 10px;
          }
        }
      }
    }

    .group_7 {
      padding: 21px 15px 26px;

      .image_17 {
        width: 56px;
        height: 57px;
      }

      .group_8 {
        margin: 3.5px 0 2px;

        .text_15 {
          margin-left: 3.5px;
        }

        .text_16 {
          margin-left: 2px;
          line-height: 10px;
        }

        .image_18 {
          margin-left: 15px;
        }

        .text_43 {
          margin-left: 1.5px;
          line-height: 10px;
        }

        .image_19 {
          margin-left: 16.5px;
        }

        .text_44 {
          line-height: 9.5px;
        }

        .image_5 {
          margin-left: 12px;
        }

        .text_26 {
          margin-left: 2.5px;
          line-height: 10px;
        }

        .image_20 {
          margin-left: 13.5px;
        }
      }

      .group_1 {
        padding-top: 11px;

        .image_22 {
          width: 59px;
          height: 59px;
        }

        .group_9 {
          margin: 3px 0 4px;

          .text_17 {
            margin-left: 1.5px;
            line-height: 16.5px;
          }

          .text_18 {
            margin-left: 2px;
            line-height: 10px;
          }

          .image_25 {
            margin-left: 15px;
          }

          .text_19 {
            margin-left: 1.5px;
            line-height: 10px;
          }

          .image_23 {
            margin-left: 15.5px;
          }

          .text_30 {
            line-height: 9.5px;
          }

          .image_24 {
            margin-left: 12px;
          }

          .text_20 {
            margin-left: 2.5px;
            line-height: 10px;
          }

          .image_26 {
            margin-left: 11.5px;
          }

          .text_21 {
            margin-left: 2px;
          }
        }
      }
    }

    .group_10 {
      padding: 13px 16px 32.5px 16px;

      .image_27 {
        width: 57px;
        height: 57px;
      }

      .text_22 {
        margin-left: 15px;
      }

      .equal-division_2 {
        padding-left: 12px;
        padding-right: 2.5px;
        width: 284.5px;

        .group_11 {
          flex: 1 1 43px;

          .text_34 {
            line-height: 10px;
          }

          .text_35 {
            line-height: 10px;
          }

          .text_36 {
            line-height: 9.5px;
          }

          .text_37 {
            line-height: 10px;
          }
        }
      }
    }

    .equal-division-item {
      padding: 5.5px 0 6.5px;
    }

    .equal-division-item_2 {
      padding: 6.5px 0 5.5px;
    }

    .group_12 {
      padding: 4.5px 26px 32px;

      .image_28 {
        margin-top: 9.5px;
        width: 48px;
        height: 47px;
      }

      .text_23 {
        line-height: 16.5px;
      }

      .text_24 {
        line-height: 10px;
      }

      .image_29 {
        margin-left: 16px;
      }

      .text_25 {
        line-height: 10px;
      }

      .image_30 {
        margin-left: 15.5px;
        margin-top: 2px;
      }

      .text_41 {
        line-height: 9.5px;
      }

      .image_35 {
        margin-left: 13px;
      }

      .text_42 {
        margin-left: 1.5px;
        line-height: 10px;
      }

      .image_33 {
        margin-left: 12.5px;
      }
    }
  }
</style>