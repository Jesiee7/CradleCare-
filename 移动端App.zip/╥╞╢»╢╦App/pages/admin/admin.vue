<template>
  <view>
    <u-navbar title="用户管理" background="#91919114" :custom-back="back">
    </u-navbar>

    <u-button type="success" size="mini" @click="addClick" class="add">添加</u-button>
    <u-table>
      <u-tr>
        <u-th>用户名</u-th>
        <u-th>账号</u-th>
        <u-th>密码</u-th>
        <u-th>权限</u-th>
      </u-tr>
      <u-swipe-action :show="show" :index="index" v-for="(item, index) in yonghu" :key="item.id" @click="tableClick"
        @open="tableOpen" :options="options">
        <view class="item u-border-bottom">
          <u-tr>
            <u-td>{{item.name}}</u-td>
            <u-td>{{item.id}}</u-td>
            <u-td>{{item.password}}</u-td>
            <u-td>{{item.type}}</u-td>
          </u-tr>
        </view>
      </u-swipe-action>
    </u-table>


    <!--弹出层-->
    <u-popup v-model="pop_show" mode="center" width="600rpx" height="300px" closeable="true">
      <view class="popup">
        <u-form :model="add_user" ref="uForm">
          <u-form-item label-width="140" label-position="left" label="用户名" prop="name">
            <u-input :border="border" placeholder="请输入用户名" v-model="add_user.name" type="text"></u-input>
          </u-form-item>
          <u-form-item label-width="140" label-position="left" label="密码" prop="password">
            <u-input :password-icon="true" :border="border" type="password" v-model="add_user.password"
              placeholder="请输入密码"></u-input>
          </u-form-item>

          <u-form-item label-width="140" label-position="left" label="邮箱" prop="email">
            <u-input :password-icon="true" :border="border" type="email" v-model="add_user.email"
              placeholder="请输入邮箱"></u-input>
          </u-form-item>

        </u-form>
        <u-button @click="submit" class="submit">提交</u-button>
      </view>

    </u-popup>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //表格
        show: false,
        options: [{
            text: '编辑',
            style: {
              backgroundColor: '#00cc00'
            }
          },
          {
            text: '删除',
            style: {
              backgroundColor: '#dd524d'
            }
          }
        ],

        //
        logined: false,

        yonghu: [],
        //弹出层
        pop_show: false,

        user: {
          id: '',
        },

        //添加用户
        add_user: {
          id: '',
          name: '',
          password: '',
          email: '',
        },

        //
        token: '',
      }
    },
    onLoad() {
      const value = uni.getStorageSync('jwtToken')
      this.token = value
      uni.request({
        url: 'http://localhost:9096/selectall',
        data: this.user,
        method: "POST",
        header: {
          'token': this.token
        },
        success: (res) => { //返回的结果（Result）对象 {"code":200,"reslut":...} 在
          console.log(res)
          this.yonghu = res.data
        }
      });
    },

    methods: {
      back() {
        uni.switchTab({
          url: '/pages/my/my'
        })
      },

      addClick() {
        uni.navigateTo({
          url: '/pages/add-user/add-user'
        })
      },

      tableClick(index, index1) {
        this.user = this.yonghu[index]
        if (index1 == 1) {
          uni.request({
            url: 'http://localhost:9096/deleteuser',
            data: {
              id: this.user.id,
            },
            method: "POST",
            header: {
              'token': this.token
            },
            success: (res) => { //返回的结果（Result）对象 {"code":200,"reslut":...} 在
              console.log(res)
              uni.request({
                url: 'http://localhost:9096/selectall',
                data: this.user,
                method: "POST",
                header: {
                  'token': this.token
                },
                success: (res) => { //返回的结果（Result）对象 {"code":200,"reslut":...} 在
                  console.log(res)
                  this.yonghu = res.data
                }
              });
            }
          });
        } else {
          this.add_user.id = this.yonghu[index].id
          console.log(this.add_user.id)
          this.pop_show = true;
        }
      },

      tableOpen() {},

      //弹出层提交按钮
      submit() {
        uni.request({
          url: 'http://localhost:9096/changeuser',
          data: this.add_user,
          method: "POST",
          header: {
            'token': this.token
          },
          success: (res) => {
            console.log(res)
            this.pop_show = false
            uni.request({
              url: 'http://localhost:9096/selectall',
              data: this.user,
              method: "POST",
              header: {
                'token': this.token
              },
              success: (res) => { //返回的结果（Result）对象 {"code":200,"reslut":...} 在
                console.log(res)
                this.yonghu = res.data
              }
            });
          }
        });
      }

    },
  }
</script>

<style>
  .popup {
    margin: 20rpx;
  }

  .add {
    margin: 30rpx;
  }

  .submit {
    width: 200rpx;
    margin-top: 20rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
</style>