<template>
  <view>
    <u-navbar back-text="" :background="background" :custopm-back="back">
      <u-tabs :list="list" :is-scroll="false" :current="current" @change="change" active-color="#ff0b89" class="tabs"
        bg-color="#d9d9d914"></u-tabs>
    </u-navbar>

    <!---->
    <view v-if="current == 0">
      <view class="wrap">
        <u-swiper :list="wrap_list" height="378"></u-swiper>
      </view>

      <view class="mid">推荐阅读</view>

      <view class="guangchang">
        <view class="guangchang-item1">
          <u-avatar :src="yonghu.image"></u-avatar>
          <view class="guangchang-item2">
            <view class="touxiang-text1">{{yonghu.name}}</view>
            <view>1岁10天</view>
          </view>
        </view>
        <view class="guangchang-item3">
          <view class="guangchang-text2">1111111</view>
          <image src=""></image>
        </view>
        <view class="guangchang-item4">
          <view class="guangchang-text3">
            <image src="../../static/jpinglun.png" class="img1"></image>
            <view>1263</view>
          </view>
          <view class="guangchang-text3">
            <image src="/static/jshoucang.png" class="img1"></image>
            <view>163</view>
          </view>
        </view>
      </view>

      <view class="guangchang">
        <view class="guangchang-item1">
          <u-avatar :src="yonghu.image"></u-avatar>
          <view class="guangchang-item2">
            <view class="touxiang-text1">{{yonghu.name}}</view>
            <view>1岁10天</view>
          </view>
        </view>
        <view class="guangchang-item3">
          <view class="guangchang-text2">1111111</view>
          <image src=""></image>
        </view>
        <view class="guangchang-item4">
          <view class="guangchang-text3">
            <image src="../../static/jpinglun.png" class="img1"></image>
            <view>1263</view>
          </view>
          <view class="guangchang-text3">
            <image src="/static/jshoucang.png" class="img1"></image>
            <view>163</view>
          </view>
        </view>
      </view>


    </view>

    <!---->
    <view v-if="current == 1">
      <view class="jingyan-top">
        <view>经验是姐妹们分享的使用内容</view>
        当前累积49419个姐妹分享了73266个经验
      </view>

      <view class="jingyan-topic">
        <view class="topic">
          精选主题
        </view>
        <view class="jingyan-item1">
          <view class="jingyan-item2">
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>摆烂带娃日记</view>
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>春季喂养日记</view>
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>宝宝换季病</view>
          </view>
          <view class="jingyan-item2">
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>我的生产日记</view>
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>萌宝春日作战</view>
            <view class="jingyan-text1"><text class="jingyan-text2">#</text>哄睡小妙招</view>
          </view>
        </view>
      </view>

      <!---->
      <view class="mid">推荐阅读</view>
      <view class="guangchang">
        <view class="guangchang-item1">
          <u-avatar :src="yonghu.image"></u-avatar>
          <view class="guangchang-item2">
            <view class="touxiang-text1">{{yonghu.name}}</view>
            <view>1岁10天</view>
          </view>
        </view>
        <view class="guangchang-item3">
          <view class="guangchang-text2">1111111</view>
          <image src=""></image>
        </view>
        <view class="guangchang-item4">
          <view class="guangchang-text3">
            <image src="../../static/jpinglun.png" class="img1"></image>
            <view>1263</view>
          </view>
          <view class="guangchang-text3">
            <image src="/static/jshoucang.png" class="img1"></image>
            <view>163</view>
          </view>
        </view>
      </view>

    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        list: [{
          name: '广场'
        }, {
          name: '经验'
        }],
        current: 0,
        yonghu: {
          image: '',
        },

        wrap_list: [{
            image: '/static/微信图片_202404161541281.png',
            title: '1'
          },
          {
            image: '/static/微信图片_202404161541283.png',
            title: '2'
          }, {
            image: '/static/微信图片_202404161541282.png',
            title: '3'
          }
        ],
      }
    },

    onShow() {
      try {
        const value = uni.getStorageSync('user')
        if (value) {
          if (!this.logined) { //从未登录变为登录
            this.yonghu = value
            console.log(value)
          }
          this.logined = true
        } else {
          this.logined = false
        }
      } catch (e) {
        // error
      }
    },

    methods: {
      back() {
        uni.switchTab({
          url: '/pages/my/my'
        })
      },

      change(index) {
        this.current = index;
      },
    }
  }
</script>

<style>
  .tabs {
    width: 600rpx;
  }

  /**/
  .wrap {
    margin: 30rpx 40rpx;
    width: 672rpx;
    height: 400rpx;
  }

  .guangchang {
    background-color: #fff;
    margin-top: 40rpx;
    margin-left: 40rpx;
    padding: 20rpx 30rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 670rpx;
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  .guangchang-item1 {
    display: flex;
    flex-direction: row;
  }

  .guangchang-item2 {
    margin-left: 30rpx;
  }

  .guangchang-item3 {
    margin-top: 30rpx;
  }

  .guangchang-text2 {
    font-size: 35rpx;
    font-weight: bold;
  }

  .guangchang-item4 {
    display: flex;
    flex-direction: row;
    margin-left: 330rpx;
    margin-top: 20rpx;
  }

  .guangchang-text3 {
    display: flex;
    flex-direction: row;
  }

  .img1 {
    margin-left: 40rpx;
    margin-right: 10rpx;
    width: 40rpx;
    height: 40rpx;
  }

  /**/
  .jingyan-top {
    margin-top: 30rpx;
    height: 100%;
    width: 100%;
    padding: 30rpx 30rpx;
    font-size: 30rpx;
  }

  .jingyan-topic {
    background-color: #fff;
    margin-top: 40rpx;
    margin-left: 20rpx;
    padding: 20rpx 40rpx;
    border-radius: 10px 10px 10px 10px / 10px 10px 10px 10px;
    box-shadow: 10rpx 8rpx 80rpx #00000014;
    width: 710rpx;
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  .topic {
    font-size: 35rpx;
    font-weight: bold;
  }

  .jingyan-item2 {
    margin-top: 30rpx;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
  }

  .jingyan-text1 {
    font-size: 30rpx;
  }

  .jingyan-text2 {
    color: #ff0b89;
    font-size: 30rpx;
    font-weight: bolder;
    margin-right: 10rpx;
  }

  .mid {
    margin: 20rpx 20rpx;
    font-size: 30rpx;
    color: #17181714;
  }
</style>