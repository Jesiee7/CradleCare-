<template>
  <view>
    <view>
      <view class="group1">
        <text class="text1">湿度：24</text>
        <image class="image_2"
          src="https://ide.code.fun/api/image?token=660b7e8cd52b770011521842&name=8d916e2e86158c1ce61f219e3ffdf352.png" />
      </view>

      <view class="text2">历史湿度</view>

    </view>

    <view class="charts-box">
      <qiun-data-charts type="line" :opts="opts" :chartData="chartData" />
    </view>

  </view>
</template>

<script>
  export default {
    data() {
      return {
        chartData: {},
        //您可以通过修改 config-ucharts.js 文件中下标为 ['line'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
        opts: {
          color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4", "#ea7ccc"],
          padding: [15, 10, 0, 15],
          enableScroll: false,
          legend: {},
          xAxis: {
            disableGrid: true
          },
          yAxis: {
            gridType: "dash",
            dashLength: 2
          },
          extra: {
            line: {
              type: "straight",
              width: 2,
              activeType: "hollow"
            }
          }
        }
      };
    },
    onReady() {
      this.getServerData();
    },
    methods: {
      getServerData() {
        //模拟从服务器获取数据时的延时
        setTimeout(() => {
          //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
          let res = {
            categories: ["2018", "2019", "2020", "2021", "2022", "2023"],
            series: [{
                name: "4.1",
                data: [35, 8, 25, 37, 4, 20]
              },
              {
                name: "4.2",
                data: [70, 40, 65, 100, 44, 68]
              },
              {
                name: "4.3",
                data: [100, 80, 95, 150, 112, 132]
              }
            ]
          };
          this.chartData = JSON.parse(JSON.stringify(res));
        }, 500);
      },
    }
  };
</script>

<style>
  .group1 {
    display: flex;
    margin: 50rpx 40rpx;
    padding: 14rpx 28rpx 44rpx;
    background-image: linear-gradient(114.1deg, #0095ff -0.6%, #0069b4 99.1%);
    border-radius: 20rpx;

  }

  .text1 {
    color: #fff;
    font-size: 40rpx;
    font-weight: bold;
  }

  .image_2 {
    margin-left: 200rpx;
    filter: blur(7rpx);
    width: 128rpx;
    height: 128rpx;
  }

  .text2 {
    line-height: 38rpx;
    margin: 20rpx;
    font-size: large;
    padding-left: 15rpx;
    display: flex;
    align-items: center;
    border-left: 3px solid rgb(47, 159, 233);
  }

  .charts-box {
    margin-top: 50rpx;
    width: 100%;
    height: 300px;
  }
</style>