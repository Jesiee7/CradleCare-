<template>
  <view class="wrap">
    <view class="wrap">
      <view class="u-avatar-wrap">
        <image class="u-avatar-demo" :src="avatar" mode="aspectFill"></image>
      </view>
      <u-button @tap="chooseAvatar">进入裁剪页</u-button>
    </view>

    <u-form :model="yonghu" ref="uForm">
      <u-form-item label-width="140" label-position="left" label="用户名" prop="name">
        <u-input :border="border" placeholder="请输入用户名" v-model="yonghu.name" type="text"></u-input>
      </u-form-item>
      <u-form-item label-width="140" label-position="left" label="账号" prop="id">
        <u-input :border="border" placeholder="请输入账号" v-model="yonghu.id" type="text"></u-input>
      </u-form-item>
      <u-form-item label-width="140" label-position="left" label="邮箱" prop="email">
        <u-input :password-icon="true" :border="border" type="email" v-model="yonghu.email"
          placeholder="请输入邮箱"></u-input>
      </u-form-item>
      <u-form-item label-width="140" label-position="left" label="密码" prop="password">
        <u-input :password-icon="true" :border="border" type="password" v-model="yonghu.password"
          placeholder="请输入密码"></u-input>
      </u-form-item>
      <u-form-item label-width="140" label-position="left" label="确认密码" prop="rpassword">
        <u-input :password-icon="true" :border="border" type="password" v-model="yonghu.rpassword"
          placeholder="再输一次密码"></u-input>
      </u-form-item>
      <u-form-item label-width="140" label-position="left" label="验证码" prop="yanzheng">
        <u-input :password-icon="true" :border="border" type="password" v-model="yonghu.yanzheng"
          placeholder="请输入验证码"></u-input>
        <u-toast ref="uToast"></u-toast>
        <u-verification-code :seconds="seconds" @end="end" @start="start" ref="uCode"
          @change="codeChange"></u-verification-code>
        <u-button class="button2" @click="yanzhengClick">{{tips}}</u-button>
      </u-form-item>

      <u-form-item label-width="140" label-position="left" label="用户类别" prop="type">
        <u-radio-group v-model="yonghu.type" @change="radioGroupChange">
          <u-radio @change="radioChange" v-for="(item, index) in list" :key="index" :name="item.val"
            :disabled="item.disabled">
            {{item.txt}}
          </u-radio>
        </u-radio-group>
      </u-form-item>
    </u-form>
    <u-button @click="submit">提交</u-button>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        border: true,
        yonghu: {
          name: '',
          id: '',
          password: '',
          rpassword: '',
          type: '',
          email: '',
          num: '',
          yanzheng: '',
        },
        list: [{
            val: 'super',
            txt: "超级用户",
            disabled: false
          },
          {
            val: 'normal',
            txt: "普通用户",
            disabled: false
          }
        ],

        //shangchuan图片
        action: 'http://192.168.100.17/index.php/index/index/upload', // 演示地址
        showUploadList: false,
        uUpload: {}, // 组件实例
        avatar: 'https://cdn.uviewui.com/uview/common/logo.png',

        //图片
        image: '',

        //验证码
        token: '',
        ma: '',

        //
        tips: '获取验证码',
        // refCode: null,
        seconds: 60,
      }
    },
    created() {
      // 监听从裁剪页发布的事件，获得裁剪结果
      uni.$on('uAvatarCropper', path => {
        this.avatar = path;
        // 可以在此上传到服务端
        uni.uploadFile({
          url: 'http://localhost:9096/upload',
          filePath: path,
          name: 'image',
          complete: (res) => {
            res.data = res.data.split('"')
            if (res.data[3] * 1 == 1) {
              uni.setStorageSync('image', res.data[7]);
              this.image = res.data[7];
              console.log(this.image)
            } else {
              this.$u.toast('更换头像失败') //提示框
            }
          }
        });
      })
    },
    methods: {
      submit() {
        if (this.yonghu.password != this.yonghu.rpassword) {
          this.$u.toast("两次输入密码不同")
          return
        }
        if (this.yonghu.yanzheng == this.ma) {
          uni.request({
            url: 'http://localhost:9096/sign',
            data: {
              name: this.yonghu.name,
              id: this.yonghu.id,
              password: this.yonghu.password,
              type: this.yonghu.type,
              email: this.yonghu.email,
              image: this.image,
            },
            method: "POST",
            success: (res) => {

              if (res.data.code * 1 == 1) {
                uni.request({
                  url: 'http://localhost:9096/addbaby',
                  data: {
                    id: this.yonghu.id,
                    babyname: this.yonghu.name,
                    location: '主卧室',
                    age: '11',
                  },
                  method: "POST",
                  header: {
                    'token': this.token
                  },
                  success: (res) => {
                    console.log(res)
                  }
                });
                uni.navigateTo({
                  url: '/pages/admin/admin'
                }) //返回登录⻚⾯ 
              } else {
                this.$u.toast('注册失败')
              }
            }
          });
        } else {
          this.$u.toast('验证码错误')
        }
      },
      radioChange(e) {
        this.yonghu.type = e
      },

      /**/
      chooseAvatar() {
        // 此为uView的跳转方法，详见"文档-JS"部分，也可以用uni的uni.navigateTo
        this.$u.route({
          // 关于此路径，请见下方"注意事项"
          url: '/uview-ui/components/u-avatar-cropper/u-avatar-cropper',
          // 内部已设置以下默认参数值，可不传这些参数
          params: {
            // 输出图片宽度，高等于宽，单位px
            destWidth: 800,
            // 裁剪框宽度，高等于宽，单位px
            rectWidth: 300,
            // 输出的图片类型，如果'png'类型发现裁剪的图片太大，改成"jpg"即可
            fileType: 'jpg',
          }
        })
      },

      /**/
      yanzhengClick() {
        if (!this.ma) {
          // 模拟向后端请求验证码
          uni.showLoading({
            title: '正在获取验证码'
          })
          setTimeout(() => {
            uni.hideLoading();
            // 这里此提示会被this.start()方法中的提示覆盖
            this.$u.toast('验证码已发送');
            // 通知验证码组件内部开始倒计时
            this.$refs.uCode.start();
          }, 2000);
        } else {
          this.$u.toast('倒计时结束后再发送');
        }

        uni.request({
          url: 'http://localhost:9096/sendemail',
          data: {
            'to': this.yonghu.email
          },
          method: "POST",
          success: (res) => { //返回的结果（Result）对象 {"code":200,"reslut":...} 在
            this.ma = res.data.num
            console.log(this.ma)
          }
        });


      },

      //
      codeChange(text) {
        this.tips = text;
      },
      end() {
        this.$u.toast('倒计时结束');
      },
      start() {
        this.$u.toast('倒计时开始');
      }
    }
  }
</script>

<style>
  .wrap {
    padding: 24rpx;
  }

  .u-avatar-wrap {
    margin-top: 80rpx;
    overflow: hidden;
    margin-bottom: 80rpx;
    text-align: center;
  }

  .u-avatar-demo {
    width: 150rpx;
    height: 150rpx;
    border-radius: 100rpx;
  }

  .button2 {
    margin-left: 10rpx;
  }
</style>